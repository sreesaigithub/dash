import React, { useContext } from "react";
import { AuthContext } from "../providers/authProvider";
import Spinner from "../components/Dashboard/ExecutiveDashboard/Overview/spinner";

export const PrivateRoute = ({ children }) => {
  const auth = useContext(AuthContext);
  if (auth.isAuthenticated()) {
    // user is not authenticated
    return children;
  } else {
    auth.signinRedirect();
    return <Spinner><i class="fa fa-spinner" aria-hidden="true"></i></Spinner>
  }
};
