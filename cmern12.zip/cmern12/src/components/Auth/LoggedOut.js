import React, { useState } from "react";
import { Modal } from "react-bootstrap";
//import ReportsDashboard from "../Dashboard/reportsdashboard";
import Home from "../Home/Home";
import "./LoggedOut.css";

function LoggedOut() {
  const [show, setShow] = useState(true);

  const closeModal = () => {
    setShow(false);
  };

  return (
    <>
      <Home />

      {show && (
        <Modal show={show} onHide={() => closeModal()}>
          <Modal.Header closeButton>
            <h3 className="modal-title">Session Expired</h3>
          </Modal.Header>
          <Modal.Body>
            <div className="d-flex justify-content-center">
              <h4>
                Your session has expired. Please click on{" "}
                {<a href="/cocwp">Home</a>} to login again.
              </h4>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <a
              href="#"
              className="btn btn-primary"
              data-dismiss="modal"
              onClick={() => {
                closeModal();
              }}
            >
              OK
            </a>
          </Modal.Footer>
        </Modal>
      )}
    </>
  );
}

export default LoggedOut;
