import React, { useEffect } from 'react';
import { Divider, FormControl, FormControlLabel, Grid, InputLabel, MenuItem, Paper, Radio, RadioGroup, Select, ToggleButton, ToggleButtonGroup } from '@mui/material';
import { Box, styled } from '@mui/system';
import BarChart from './graphs/performanceHighlightsBarChart';
import axios from 'axios';
import HccChart1 from './graphs/hccPmpmChart';
import HccChart2 from './graphs/hccUtilizationChart';
import HccChart3 from './graphs/hccUnitCostChart';
import './Overview.css';
import Rank from './rank';
import Spinner from './spinner';
import TargetLabel from './targetlabel';
import PriorLabel from './priorlabel';
import Moment from 'react-moment';
import LineChartTrends from './graphs/trendLineChart';
import { MenuProps1 } from "./utils";
import Lob from "./dropDowns/lob";
import Servicearea from './dropDowns/serviceareastate';
import Product from './dropDowns/product';
import Funding from './dropDowns/funding';
import Popup from './Popup';

const cancelledError = "CanceledError"

const NoDataPopup = { title: "No data available", content: "Pls try again later." }

const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: 'white',
  padding: '10px',
  textAlign: 'left',
  color: '#1a3673',
  fontSize: '0.875rem',
}));
//export const url= "http://localhost:8080/cocwp/api";
export const url = window.__RUNTIME_CONFIG__.REACT_APP_BASE_API_URL;
export default function Overview() {
  const [laodingMaster, setLoadingMaster] = React.useState(true);
  const [loadingfundingTypeClassMap, setLoadingfundingTypeClassMap] = React.useState(false);
  const [type, setType] = React.useState('targetVsActual');
  const [time, setTime] = React.useState('m');
  const [iem, setIem] = React.useState('');
  const [sa, setSA] = React.useState([]);
  const [serviceAreaList, setServiceAreaList] = React.useState([]);
  const [lob, setLOB] = React.useState('Commercial');
  const [lobList, setLOBList] = React.useState([]);
  const [mbuclass, setMBUclass] = React.useState(['Commercial']);
  const [fundingType, setFundingType] = React.useState(['All']);
  const [fundingClass, setFundingClass] = React.useState(['All']);
  const [amountType, setAmountType] = React.useState('Paid');
  const [product, setProduct] = React.useState(['All']);
  const [productList, setProductList] = React.useState([]);
  const [iemList, setIemList] = React.useState([]);
  const [ibnr, setIbnr] = React.useState('Y');
  const [paidClaimsY1, setPaidClaimsY1] = React.useState([]);
  const [claimVarianceType, setClaimVarianceType] = React.useState('inpatient');
  const [paidClaimsData, setPaidClaimsData] = React.useState({});
  const [fundingParent, setFundingParent] = React.useState([]);
  const [performanceApiLoading, setPerformanceApiLoading] = React.useState(true);
  const [trendApiLoading, setTrendApiLoading] = React.useState(true);
  const [varianceApiLoading, setVarianceApiLoading] = React.useState(true);
  const [noDataPopup, setNoDataPopup] = React.useState(false);

  const controller = new AbortController();
  const apiConfig = { signal: controller.signal };

  const handleType = (event, newType) => {
    setType(newType);
    if(newType == "targetVsActual" && claimVarianceType == "pharmacy"){
      setClaimVarianceType('inpatient');
    }
  };

  const handleClaimVarianceType = (event, newType) => {
    setClaimVarianceType(newType);
  };
  const handleTime = (event, newTime) => {
    if (newTime !== null) {
      setTime(newTime);
    }
  };
  const handleIem = (event) => {
    setIem(event.target.value);
  };

  const handleAmountType = (event) => {
    setAmountType(event.target.value);
  };

  const handleIbnr = (event) => {
    setIbnr(event.target.value);
  };

  const [hccGraph1, setHccGraph1] = React.useState([]);
  const [hccGraph2, setHccGraph2] = React.useState([]);
  const [hccGraph3, setHccGraph3] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  const [allowedPmPm, setAllowedPmPm] = React.useState(null);
  const [revenuePmPm, setRevenuePmPm] = React.useState(null);
  const [paidClaims, setPaidClaims] = React.useState([]);
  const [memberMonths, setMemberMonths] = React.useState([]);
  const [endingMembership, setEndingMembership] = React.useState(null);
  const [mlr, setMlr] = React.useState(null);

  useEffect(() => {
    setLoadingMaster(true);
    loadLobList();
    loadIemList();
    setLoadingMaster(false);
  }, []);

  useEffect(() => {
    setTrendApiLoading(true);
    if (iem !== '' && lob !== '') {
      paidClaimTrends({
        "type": claimVarianceType,
        "product": product == 'All' ? [] : product,
        "lob": lob,
        "incurredMonth": iem,
        "mbuclass": getMbuClass(),
        "fundingclass": type == 'targetVsActual' ? '' : fundingClass == 'All' ? '' : fundingClass,
        "fundingtype": type == 'targetVsActual' ? [] : fundingType == 'All' ? [] : fundingType,
        "serviceArea": getSA(),
        "duration": time,
        "viewType": type,
        "amountType": amountType,
        "ibnr": ibnr,
        "budgets": [],
      });
    }
    return () => { controller.abort() }
  }, [ibnr, claimVarianceType]);

  useEffect(() => {
    setTrendApiLoading(true);
    setVarianceApiLoading(true);
    if (iem !== '' && lob !== '') {
      paidClaimTrends({
        "type": claimVarianceType,
        "product": product == 'All' ? [] : product,
        "lob": lob,
        "incurredMonth": iem,
        "mbuclass": getMbuClass(),
        "fundingclass": type == 'targetVsActual' ? '' : fundingClass == 'All' ? '' : fundingClass,
        "fundingtype": type == 'targetVsActual' ? [] : fundingType == 'All' ? [] : fundingType,
        "serviceArea": getSA(),
        "duration": time,
        "viewType": type,
        "amountType": amountType,
        "ibnr": ibnr,
        "budgets": [] 
      });
      claimVariance(claimVarianceType);
    }
    return () => { controller.abort() }
  }, [amountType]);

  useEffect(() => {
    if (lob !== '') {
      setSA(['All']);
      setProduct(['All']);
      loadServiceAreaList(lob, getMbuClass());
      if (sa !== '') {
        if (!loadingfundingTypeClassMap) {
          loadFundingTypeClassList(lob, getSA(), getMbuClass());
        }
      }
    }
  }, [lob]);

  useEffect(() => {
    if (lob !== '') {
      setProduct(['All']);
      if (!loadingfundingTypeClassMap) {
        loadFundingTypeClassList(lob, getSA(), getMbuClass());
      }
    }
  }, [sa]);

  useEffect(() => {
    if (lob !== '') {
      setProduct(['All']);
      loadProductList(lob, getSA(), getMbuClass());
    }
  }, [mbuclass]);

  useEffect(() => {
    if (!laodingMaster) {
      setPerformanceApiLoading(true);
      setTrendApiLoading(true);
      setVarianceApiLoading(true);
      if (iem !== "" && lob !== "") {
        let data = {
          "serviceArea": getSA(),
          "product": product == 'All' ? [] : product,
          "lob": lob,
          "incurredMonth": iem,
          "mbuclass": getMbuClass(),
          "fundingclass": type == 'targetVsActual' || lob != "Commercial" ? '' : fundingClass == 'All' ? '' : fundingClass,
          "fundingtype": type == 'targetVsActual' || lob != "Commercial" ? [] : fundingType == 'All' ? [] : fundingType,
          "duration": time,
          "viewType": type,
          "budgets": [] 
        }
        functionchart(data);

        paidClaimTrends({
          "type": claimVarianceType,
          "serviceArea": getSA(),
          "product": product == 'All' ? [] : product,
          "lob": lob,
          "incurredMonth": iem,
          "mbuclass": getMbuClass(),
          "fundingclass": type == 'targetVsActual' || lob != "Commercial" ? '' : fundingClass == 'All' ? '' : fundingClass,
          "fundingtype": type == 'targetVsActual' || lob != "Commercial" ? [] : fundingType == 'All' ? [] : fundingType,
          "duration": time,
          "viewType": type,
          "amountType": amountType,
          "ibnr": ibnr,
          "budgets":  [] 
        });

        claimVariance(claimVarianceType);
      }
    }
    return () => { controller.abort() }
  }, [laodingMaster, type, time, iem, lob, sa, mbuclass, fundingType, fundingClass, product]);

  useEffect(() => {
    setVarianceApiLoading(true);
    if (iem !== "" && lob !== "") {
      claimVariance(claimVarianceType);
    }
    return () => { controller.abort() }
  }, [claimVarianceType]);

  const functionchart = async (data) => {
    axios.post(url + `/dashboard/overview/performanceHighlights`, data, apiConfig)
      .then(async (response) => {
        setLoading(false);
        setAllowedPmPm(response?.data?.data?.allowedPmPm);
        setRevenuePmPm(response?.data?.data?.revenuePmPm);
        setPaidClaims(response.data.data.paidClaims);
        setMemberMonths(response.data.data.memberMonths);
        setEndingMembership(response.data.data['endingMembership']);
        setMlr(response.data.data.mlr);
        setPerformanceApiLoading(false);
      })
      .catch(function (error) {
        if (error.name !== cancelledError) {
          setAllowedPmPm('error');
          setRevenuePmPm('error');
          setPaidClaims('error');
          setMemberMonths('error');
          setEndingMembership('error');
          setMlr('error');
          setPerformanceApiLoading(false);
        }

      });
  }
  const paidClaimTrends = async (data) => {
    axios.post(url + `/dashboard/overview/paidClaimTrend`, data, apiConfig)
      .then(async (response) => {
        setPaidClaimsData(response.data.data);
        setPaidClaimsY1(response.data.data.y1Value);
        setTrendApiLoading(false);
      })
      .catch(function (error) {
        if (error.name !== cancelledError) {
          setPaidClaimsY1('error');
          setTrendApiLoading(false);
        }
      });
  }

  function getMbuClass() {
    if (mbuclass.length === 1 && mbuclass[0] === 'All') {
      return [];
    }
    return mbuclass;
  }
  function getSA() {
    if (sa.length === 1 && sa[0] === 'All') {
      return [];
    }
    return sa;
  }

  const claimVariance = async (claimtype, tmpAmountType) => {
    let data = {
      "type": claimtype,
      "serviceArea": getSA(),
      "product": product == 'All' ? [] : product,
      "lob": lob,
      "incurredMonth": iem,
      "mbuclass": getMbuClass(),
      "fundingclass": type == 'targetVsActual' || lob != "Commercial" ? '' : fundingClass == 'All' ? '' : fundingClass,
      "fundingtype": type == 'targetVsActual' || lob != "Commercial" ? [] : fundingType == 'All' ? [] : fundingType,
      "duration": time,
      "viewType": type,
      "amountType": tmpAmountType ? tmpAmountType : amountType,
      "segment": "",
      "budgets":  [] 
    }
    axios.post(url + `/dashboard/overview/claimVariance`, data, apiConfig)
      .then(async (response) => {
        setHccGraph1(response.data.data.graph1);
        setHccGraph2(response.data.data.graph2);
        setHccGraph3(response.data.data.graph3);
        setVarianceApiLoading(false);
      })
      .catch(function (error) {
        if (error.name !== cancelledError) {
          setHccGraph1('error');
          setVarianceApiLoading(false);
        }
      });
  }

  const loadLobList = async (data) => {
    axios.get(url + `/lob`)
      .then(async (response) => {
        if (response.data.status === 200) {
          let data = response.data.data;
          for (let lobItem of data) {
            if (lobItem.label === 'Commercial') {
              lobItem.checked = true;
            }
          }
          if (data.length === 0) {
            //show popup
            setNoDataPopup(true)

          }
          setLOBList(data);

        }
      })
      .catch(function (error) {
        setNoDataPopup(true)
      });
  }
  const loadProductList = async (tmplob, tmpsa, tmpmbu) => {
    let data = {
      "lob": tmplob,
      "serviceArea": tmpsa,
      "mbuClass": tmpmbu
    }
    axios.post(url + `/product`, data)
      .then(async (response) => {
        if (response.data.status === 200) {
          let data = response.data.data;
          let allItem = data.find(x => x.label == 'All')
          if (allItem) {
            allItem.isDefaultValue = true
          }
          setProductList(data);
        }
      })
      .catch(function (error) {
      });
  }
  const loadIemList = async (data) => {
    axios.get(url + `/incurredMonth`)
      .then(async (response) => {
        if (response.data.status === 200) {
          let data = response.data.data;
          setIemList(data);
          if (data.length > 0) {
            setIem(data[0]);
          }
        }
      })
      .catch(function (error) {
      });
  }

  const loadServiceAreaList = async (tmplob, tmpmbu) => {
    let data = {
      "lob": tmplob,
      "mbuClass": tmpmbu
    }
    axios.post(url + '/serviceArea', data)
      .then(async (response) => {
        if (response.data.status === 200) {
          let data = response.data.data;
          let allItem = data.find(x => x.label == 'All')
          if (allItem) {
            allItem.isDefaultValue = true
          }
          setServiceAreaList(data);
        }
      })
      .catch(function (error) {
      });
  }

  const loadFundingTypeClassList = async (tmpLob, tmpSa, tmpmbu) => {
    let data = {
      "lob": tmpLob,
      "mbuClass": tmpmbu,
      "serviceArea": tmpSa,
    }
    setLoadingfundingTypeClassMap(true);
    axios.post(url + '/fundingTypeClass', data)
      .then(async (response) => {
        if (response.data.status === 200) {
          setFundingParent(response.data.data);
          setLoadingfundingTypeClassMap(false);
        }
      })
      .catch(function (error) {
        setLoadingfundingTypeClassMap(false);
      });
  }

  return (
    <div className=" justify-content-center flex-column flex-lg-row justify-content-lg-between " >
      {noDataPopup && <Popup open={noDataPopup} title={NoDataPopup.title} content={NoDataPopup.content} />}
      <div>
        <span style={{ fontSize: '25px', padding: '5px' }}>Overview</span>
      </div>
      <Divider />
      <div >
        <div >
          <div className="overviewFilter">
            <Lob dataArray={lobList} setLOB={setLOB} setMBUclass={setMBUclass} setSA={setSA} setProduct={setProduct} mbuclass={mbuclass} />
            <Servicearea dataArray={serviceAreaList} setSA={setSA} lob={lob} setProduct={setProduct} mbuClass={mbuclass} product={product} sa={sa} />
            <Product dataArray={productList} setProduct={setProduct} lob={lob} mbuClass={mbuclass} sa={sa} product={product} />
            <Funding disabled={type == "targetVsActual" || lob != "Commercial"} dataArray={fundingParent} setFundingType={setFundingType} setFundingClass={setFundingClass} lob={lob} mbuClass={mbuclass} sa={sa} product={product} />
          </div>
          <div className="overviewFilterRadio">
            <FormControl variant="standard" sx={{ m: 1, minWidth: 120 }} size="small">
              <InputLabel id="amountType-label"><span className="fontDisplay">Amount Type</span></InputLabel>
              <Select
                id="amountType"
                value={amountType}
                label="amount Type"
                style={{ fontSize: '12px' }}
                onChange={handleAmountType}
              >
                <MenuItem value={"Allowed"}>Allowed</MenuItem>
                <MenuItem value={"Paid"}>Paid</MenuItem>
              </Select>
            </FormControl>
            <div style={{ display: 'flex' }}>
              <FormControl variant="standard" sx={{ m: 1, minWidth: 160 }} size="small">
                <InputLabel id="IEM-label"><span className="fontDisplay">Incurred Ending Month</span></InputLabel>
                <Select
                  labelId="IEM-label"
                  id="IEM"
                  value={iem}
                  style={{ fontSize: '12px' }}
                  label="Incurred Ending Month"
                  onChange={handleIem}
                  MenuProps={MenuProps1}>

                  {iemList.map(function (ele, index) {
                    return <MenuItem value={ele}>
                      <Moment format="MMM YYYY" parse="YYYYMM">
                        {ele}
                      </Moment></MenuItem>;
                  })}
                </Select>
              </FormControl>
            </div>
            <div className="targetRadiogroup" >
              <FormControl>
                <RadioGroup row
                  name="radio-buttons"
                  value={type}
                  onChange={handleType}
                >
                  <FormControlLabel className="find" value="targetVsActual" control={<Radio className="targetRadioPadding" size="small" />} label={<span className="radioFontDisplay" >Target vs. Actual</span>} />
                  <FormControlLabel value="priorVsCurrent" control={<Radio className="targetRadioPadding" size="small" />} label={<span className="radioFontDisplay" >Prior vs. Current</span>} />

                </RadioGroup>
              </FormControl>
            </div>
            <br />
            <div className="togglegroup" >
              <ToggleButtonGroup
                value={time}
                color="primary"
                exclusive
                onChange={handleTime}
                size="small"
                style={{ height: 30 }}
              >
                <ToggleButton value="m" >
                  M
                </ToggleButton>
                <ToggleButton value="3m" >
                  3M
                </ToggleButton>
                <ToggleButton value="6m" >
                  6M
                </ToggleButton>
                <ToggleButton value="ytd" >
                  YTD
                </ToggleButton>
                <ToggleButton value="1y"  >
                  1Y
                </ToggleButton>
              </ToggleButtonGroup>
            </div>
          </div>
        </div>
        <div >
          <Box className="parentBox" >
            <Box className="perfomanceBox">
              <div style={{ width: '100%', padding: '10px', paddingBottom: '5px', paddingTop: '5px' }}>
                <span style={{ fontWeight: '500' }}>Performance Highlights (Incl. IBNR)</span>
                <Grid item lg={12} md={12} sm={12} >
                  <Grid container spacing={2}>
                    <Grid item lg={4} md={4} sm={4}>
                      {endingMembership == 'error' ? <span style={{ color: 'red' }}><br />Error loading data</span> :
                        <Item style={{ padding: '0px' }}>
                          <div style={{ display: 'flex', width: '100%' }}>
                            <div style={{ display: 'flex', width: '70%', padding: '10px' }}>
                              <span>Ending Membership</span>
                            </div>
                            <div style={{ textalign: 'right', width: '30%' }}>
                              <Rank value={endingMembership?.rankPercentile} ending={serviceAreaList.length - 1} />
                            </div>
                          </div>
                          {performanceApiLoading ? <Spinner></Spinner> :
                            <BarChart data={endingMembership} prop={type} sign={""} />
                          }
                        </Item>
                      }
                    </Grid>
                    <Grid item lg={4} md={4} sm={4}>
                      {memberMonths == 'error' ? <span style={{ color: 'red' }}><br /></span> :
                        <Item style={{ padding: '0px' }}>
                          <div style={{ display: 'flex', width: '100%' }}>
                            <div style={{ display: 'flex', width: '70%', padding: '10px' }}>
                              <span>Member Months</span>
                            </div>
                            <div style={{ textalign: 'right', width: '30%' }}>
                              <Rank value={memberMonths?.rankPercentile} ending={serviceAreaList.length - 1} />
                            </div>
                          </div>
                          {performanceApiLoading ? <Spinner></Spinner> :
                            <BarChart data={memberMonths} prop={type} sign={""} />}
                        </Item>}
                    </Grid>
                    <Grid item lg={4} md={4} sm={4}>
                      {revenuePmPm == 'error' ? <span style={{ color: 'red' }}><br /></span> :
                        <Item style={{ padding: '0px' }}>
                          <div style={{ display: 'flex', width: '100%' }}>
                            <div style={{ display: 'flex', width: '70%', padding: '10px' }}>
                              <span>Revenue PMPM</span>
                            </div>
                            <div style={{ textalign: 'right', width: '30%' }}>
                              {type == "targetVsActual" ? <span></span> : <Rank value={revenuePmPm?.rankPercentile} ending={serviceAreaList.length - 1} />}
                            </div>
                          </div>
                          {type == "targetVsActual" ? <Box className="comingsoonbox" ><br />Coming Soon</Box> : performanceApiLoading ? <Spinner></Spinner> :
                            <BarChart data={revenuePmPm} prop={type} sign={"$"} />}
                        </Item>}
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item lg={12} md={12} sm={12}>
                  <Grid container spacing={2}>
                    <Grid item lg={4} md={4} sm={4}>
                      <Box sx={{ m: 1 }} />
                      {paidClaims == 'error' ? <span style={{ color: 'red' }}><br /></span> :
                        <Item style={{ padding: '0px' }}>
                          <div style={{ display: 'flex', width: '100%' }}>
                            <div style={{ display: 'flex', width: '70%', padding: '10px' }}>
                              <span>Paid Expense PMPM</span>
                            </div>
                            <div style={{ textalign: 'right', width: '30%' }}>
                              <Rank value={paidClaims?.rankPercentile} ending={serviceAreaList.length - 1} />
                            </div>
                          </div>
                          {performanceApiLoading ? <Spinner></Spinner> :
                            <BarChart data={paidClaims} prop={type} sign={"$"} arrow={"+down"} />}
                        </Item>}
                    </Grid>
                    <Grid item lg={4} md={4} sm={4}>
                      <Box sx={{ m: 1 }} />
                      {mlr == 'error' ? <span style={{ color: 'red' }}><br /></span> :
                        <Item style={{ padding: '0px' }}>
                          <div style={{ display: 'flex', width: '100%' }}>
                            <div style={{ display: 'flex', width: '70%', padding: '10px' }}>
                              <span>MLR</span>
                            </div>
                            <div style={{ textalign: 'right', width: '30%' }}>
                              {type == "targetVsActual" ? <span></span> : <Rank value={mlr?.rankPercentile} ending={serviceAreaList.length - 1} />}
                            </div>
                          </div>
                          {type == "targetVsActual" ? <Box className="comingsoonbox" ><br />Coming Soon</Box> : performanceApiLoading ? <Spinner></Spinner> :
                            <BarChart data={mlr} prop={type} sign={"%"} />}
                        </Item>}
                    </Grid>
                    <Grid item lg={4} md={4} sm={4}>
                      <Box sx={{ m: 1 }} />
                      {allowedPmPm == 'error' ? <span style={{ color: 'red' }}><br /></span> :
                        <Item style={{ padding: '0px' }}>
                          <div style={{ display: 'flex', width: '100%' }}>
                            <div style={{ display: 'flex', width: '75%', padding: '10px' }}>
                              <span>Allowed Expense PMPM</span>
                            </div>
                            <div style={{ textalign: 'right', width: '25%' }}>
                              <Rank value={allowedPmPm?.rankPercentile} ending={serviceAreaList.length - 1} />
                            </div>
                          </div>
                          {performanceApiLoading ? <Spinner></Spinner> :
                            <BarChart data={allowedPmPm} prop={type} sign={"$"} />}
                        </Item>}
                    </Grid>
                  </Grid>
                </Grid>
              </div>
            </Box>
            <Box className="claimsBox" sx={{ display: 'flex' }} >
              <div style={{ width: '100%' }} >
                <div style={{ width: '100%', paddingLeft: '10px' }}>
                  <div className="hccRadioDiv" >
                  {type=="targetVsActual" ? <RadioGroup size="small"
                      row
                      name="row-radio-buttons-group"
                      value={claimVarianceType}
                      onChange={handleClaimVarianceType}
                      defaultValue='inpatient'
                    >
                      <FormControlLabel value="inpatient" checked={claimVarianceType == 'inpatient'} control={<Radio className="hccRadioPadding" size="small" />} label={<span className="radioFontDisplay" >IP</span>} />
                      <FormControlLabel value="outpatient" checked={claimVarianceType == 'outpatient'} control={<Radio className="hccRadioPadding" size="small" />} label={<span className="radioFontDisplay" >OP</span>} />
                      <FormControlLabel value="physician" checked={claimVarianceType == 'physician'} control={<Radio className="hccRadioPadding" size="small" />} label={<span className="radioFontDisplay" >Phy</span>} />
                      <FormControlLabel value="capitation" checked={claimVarianceType == 'capitation'} control={<Radio className="hccRadioPadding" size="small" />} label={<span className="radioFontDisplay" >Cap/Ven</span>} />
                      <FormControlLabel value="intrst" checked={claimVarianceType == 'intrst'} control={<Radio className="hccRadioPadding" size="small" />} label={<span className="radioFontDisplay" >Intrst/Net Rein/Oth</span>} />
                      <FormControlLabel value="total" checked={claimVarianceType == 'total'} control={<Radio className="hccRadioPadding" size="small" />} label={<span className="radioFontDisplay" >Total</span>} />
                    </RadioGroup>:
                    <RadioGroup size="small"
                      row
                      name="row-radio-buttons-group"
                      value={claimVarianceType}
                      onChange={handleClaimVarianceType}
                      defaultValue='inpatient'
                    >
                      <FormControlLabel value="inpatient" checked={claimVarianceType == 'inpatient'} control={<Radio className="hccRadioPadding" size="small" />} label={<span className="radioFontDisplay" >IP</span>} />
                      <FormControlLabel value="outpatient" checked={claimVarianceType == 'outpatient'} control={<Radio className="hccRadioPadding" size="small" />} label={<span className="radioFontDisplay" >OP</span>} />
                      <FormControlLabel value="physician" checked={claimVarianceType == 'physician'} control={<Radio className="hccRadioPadding" size="small" />} label={<span className="radioFontDisplay" >Phy</span>} />
                      <FormControlLabel value="pharmacy" checked={claimVarianceType == 'pharmacy'} control={<Radio className="hccRadioPadding" size="small" />} label={<span className="radioFontDisplay" >Pharm</span>} />
                      <FormControlLabel value="capitation" checked={claimVarianceType == 'capitation'} control={<Radio className="hccRadioPadding" size="small" />} label={<span className="radioFontDisplay" >Cap/Ven</span>} />
                      <FormControlLabel value="intrst" checked={claimVarianceType == 'intrst'} control={<Radio className="hccRadioPadding" size="small" />} label={<span className="radioFontDisplay" >Intrst/Net Rein/Oth</span>} />
                      <FormControlLabel value="total" checked={claimVarianceType == 'total'} control={<Radio className="hccRadioPadding" size="small" />} label={<span className="radioFontDisplay" >Total</span>} />
                    </RadioGroup>}
                  </div>
                  {/* <Item style={{ padding: "0px", marginRight: '10px' }}> */}
                  <div style={{ display: 'flex', width: '100%', padding: '0px' }}>
                    <div className="PMPMTrendLeft">{
                      amountType == "Paid" ? <span style={{ fontWeight: '500' }}> Paid Expense PMPM Trend by Type of Service</span> :
                        <span style={{ fontWeight: '500' }}>Allowed Expense PMPM Trend by Type of Service</span>
                    }
                    </div>
                    <div style={{ display: 'flex', width: '30%', }}>
                      <FormControl variant="standard" sx={{ m: 1, minWidth: 120 }} size="small">
                        <InputLabel id="including-ibnr-label"><span className="fontDisplay">Including IBNR</span></InputLabel>
                        <Select
                          labelId="including-ibnr-label"
                          id="including-ibnr"
                          value={ibnr}
                          label="Including IBNR"
                          style={{ fontSize: '12px' }}
                          onChange={handleIbnr}                >
                          <MenuItem value={'Y'}>Yes</MenuItem>
                          <MenuItem value={'N'}>No</MenuItem>
                        </Select>
                      </FormControl>
                    </div>
                  </div>
                  <div>
                    <div>
                      {paidClaimsY1 == 'error' ? <span style={{ width: '100%', color: 'red' }}>Error loading data</span> :
                        <>
                          {trendApiLoading ? <Spinner></Spinner> :
                            <LineChartTrends data={paidClaimsData} type={type} />} </>
                      }
                    </div>
                  </div>
                  <div style={{ width: '100%' }}>
                    <div>
                      <span style={{ fontWeight: '500' }}>Expense Variance by Type of Service</span>
                    </div>
                    <div>
                      {hccGraph1 == 'error' ? <span style={{ color: 'red' }}><br />Error loading data</span> :
                        <>
                          {varianceApiLoading ? <><br/><Spinner></Spinner></> :
                            <div style={{ display: 'flex', width: '100%' }}>
                              <div style={{ display: 'flex', width: '33%' }}>
                                <HccChart1 data={hccGraph1} prop={type} hcctype={claimVarianceType} />
                              </div>
                              <div style={{ display: 'flex', width: '33%' }}>
                                <HccChart2 data={hccGraph2} prop={type} hcctype={claimVarianceType} />
                              </div>
                              <div style={{ display: 'flex', width: '33%' }}>
                                <HccChart3 data={hccGraph3} prop={type} hcctype={claimVarianceType} />
                              </div>
                            </div>}
                        </>
                      }
                    </div>
                  </div>
                  {/* </Item> */}
                </div>
              </div>
            </Box>
          </Box>
        </div>
      </div>
      <div style={{ maxHeight: '10vh' }}>
        <br />
        <br />
        <br />
        <br />
        <br />

      </div>
      <div style={{ display: 'flex' }}>
        {type == "targetVsActual" ? <TargetLabel /> : <PriorLabel />}
      </div>
      <div >
        <br />

      </div>
    </div>
  )
}