import React from 'react';
import CircularProgress from '@mui/material/CircularProgress';
import './spinner.css';
import Box from '@mui/material/Box';

export default function Spinner() {
  return (
    <Box className="spinnerbox" >
      <CircularProgress className="spinnerstyle" />
    </Box>
  );
}