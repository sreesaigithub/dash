import React, { useState } from "react";
import { Modal } from "react-bootstrap";

function Popup(props) {
    const [show, setShow] = useState(true);

    const closeModal = () => {
        setShow(false);
    };

    return (
        <Modal size="sm" show={show} onHide={closeModal}>
            <Modal.Header closeButton>
                <h3 className="modal-title">{props.title}</h3>
            </Modal.Header>
            <Modal.Body>
                <h4>
                    {props.content}
                </h4>
            </Modal.Body>
            <Modal.Footer>
                <a
                    href="#"
                    className="btn btn-primary"
                    data-dismiss="modal"
                    onClick={closeModal}
                >
                    OK
                </a>
            </Modal.Footer>
        </Modal>
    );
}

export default Popup;
