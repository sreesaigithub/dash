import React from "react";
import { Bar, Chart } from "react-chartjs-2";
import ChartDataLabels from 'chartjs-plugin-datalabels';



const HccBarChart = (props) => {
  
  var label1 = "PMPM";
  var label2 = "";
  var label3 = "";
  const type = props.hcctype;
  if (type == 'inpatient') {

    label2 = "Admits/1000";
    label3 = "Cost/admit";
  };
  if (type == 'outpatient' || type == 'physician') {
    label2 = "Visits/1000";
    label3 = "Cost/visit";
  };
  if (type == 'pharmacy') {
    label2 = "Scripts/month";
    label3 = "Cost/script";
  };
  if (type == 'other') {
    label2 = "N/A";
    label3 = "N/A";
  };
  const barChartData = {
    plugins: [ChartDataLabels],
    labels: [label1, label2, label3],
    // diff: props?.data?.diffPercentage,
    datasets: [
      {
        label: props?.prop == "targetVsActual" ? "Target" : "Prior",
        backgroundColor: "#6A97DF",
        barThickness: 10,
        // maxBarLength: 13,
        minBarLength: 5,
        data: props?.prop == "targetVsActual" ? null :props?.data?.target,
        //  data:[10,200,1000065009],
        diff: props?.prop == "targetVsActual" ? null : props?.data?.diffPercentage,
        datalabels: {
          align: 'left',
          anchor: 'end',
          color: 'black',
          rotation: 0,
          font: {
            weight: ''
          }
        }
      },
      {
        label: null,
        backgroundColor: "white",
        barThickness: 20,
        data: null,
      },
      {
        label: props?.prop == "targetVsActual" ? "Actual" : "Current",
        backgroundColor: "#1A3673",
        barThickness: 10,
        // maxBarLength: 1,
        minBarLength: 5,
        data: props?.data?.actual,
        // data: [1, 54, 10754],
        diff: props?.prop == "targetVsActual" ? null : props?.data?.diffPercentage,
        datalabels: {
          align: 'right',
          anchor: 'end',
          color: 'black',
          rotation: 0,
          font: {
            weight: ''
          }
        }
      },
    ],
  };
  const option = {
    layout: {
      padding: {
        left: 0,
        right: 20,
        top: 10,
        bottom: 0
      }
    },
    plugins: [ChartDataLabels],
    plugins: {
      datalabels: {
        labels: {
          index: {
            // color: 'white',
            // rotation: 270,
            // font: {
            //   weight: 'bold'
            // },
            formatter: function (value, context) {
              if (!value) { return value; }
              else {
                if (value > 9999) {
                  if (value <= 999999) {
                    value = (value / 1000).toFixed(2) + 'K'
                  }
                  if (value <= 999999999) {
                    value = (value / 1000000).toFixed(2) + 'M'
                  }
                  if (value <= 999999999999) {
                    value = (value / 1000000000).toFixed(2) + 'B'
                  }
                  if (value <= 999999999999999) {
                    value = (value / 1000000000000).toFixed(2) + 'T'
                  }
                  return context.dataIndex == 0 || context.dataIndex == 2 ? '$' + value : value;
                }

                return context.dataIndex == 0 || context.dataIndex == 2 ? '$' + value : value;
              }

              // if(value >= 1000000  && value <= 1000000000  ){
              //   return (value/100000).toFixed(1) + 'M';
              // }
              // if(value >= 1000000000  ){
              //   return (value/1000000000).toFixed(1) + 'B';
              // }                

              // value = value.toString();
              // value = value.split(/(?=(?:...)*$)/);
              // value = value.join(',');
              // return context.dataIndex == 0 || context.dataIndex == 2 ? '$' + value : value;}
            }
          },
          name: {
            align: 'top',
            anchor: 'end',
            rotation: 0,
            font: { size: 14 },
            padding:{
              bottom:-9,              
            },

            color: function (context) { 
              var diff = context.dataset.diff ? context.dataset.diff[context.dataIndex] : 0;
              return diff < 0 ? 'green' : "red";
            },
            formatter: function (value, context) {

              var diff = context.dataset.diff ? context.dataset.diff[context.dataIndex] : 0;
              var glyph = diff < 0 ? '▼' : '▲';
              diff= diff < 0 ? Math.abs(diff) : diff;
              return  context.dataset.label == "Current" ? glyph + ' ' + Math.round(diff) + '%' : '';
            }
          },
        }
      },
      legend: {
        display: false
      },
    },
    scales: {
      x: {
        grid: {
          display: false
        }
      },
      y: {

        display: false,
        grid: {
          display: false
        }
      }
    },
  };

  const hccbarChart = (
    <Bar
      data={barChartData} height="70px" options={option} padding="0px" 
    />
  );
  return hccbarChart;
};

export default HccBarChart;