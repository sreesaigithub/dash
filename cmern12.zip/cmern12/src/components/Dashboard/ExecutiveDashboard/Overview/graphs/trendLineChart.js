import React from "react";
import { Line } from "react-chartjs-2";
// import { Chart } from "chart.js";
import Chart from "chart.js/auto";
import ChartDataLabels from "chartjs-plugin-datalabels";
import moment from 'moment';
Chart.register(ChartDataLabels);

const LineChartTrends = ({ data , type }) => {
    var title = 'Expense PMPM';
    const linedata = {
        labels: data? data.xvalue : 0,
        datasets: [
            {
                label:type == "targetVsActual" ? "Target" : "Prior",
                data:data? data.y2Value : 0,
                fill: false,
                backgroundColor: "white",
                borderColor: "#6A97DF",
                datalabels: {
                    align: 'top',
                }
            },
            {
                label:type == "targetVsActual" ? "Actual" : "Current",
                data:data? (data.y2Value.every((item) => item === 0) ? 0 : data.y1Value ): 0,
                fill: false,
                borderColor: "#1A3673",
                datalabels: {
                    align: 'top',
                }
            },
        ]
    };

    const option = {
        layout: {
            padding: {
                left: 0,
                right: 0,
                top: 0,
                bottom: 0
            }
        },
        animation: {
            duration: 0
        },
        plugins: {
            legend: {
                display: false
            },
            tooltip: {
                callbacks: {
                    title: function (tooltipItem) {
                        var value = tooltipItem[0].label;
                        var date = moment(value, "MM").format('MMM');
                        return date;
                    },
                    label: function(context) {
                        let label = context.dataset.label || '';
                
                        if (label) {
                            label += ': ';
                        }
                        if (context.parsed.y !== null) {
                            label += new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD',  minimumFractionDigits: 0,
                            maximumFractionDigits: 0 }).format(context.parsed.y);
                        }
                        return label;
                    },
                }
            },
            datalabels: {
                display: false,
                color: "black",
                labels: {
                    title: {
                        font: {
                            //weight: "bold"
                        }
                    },
                },
                formatter: function (value, context) {
                    if (!value) { return value; }
                    else {
                        value = value.toString();
                        value = value.split(/(?=(?:...)*$)/);
                        value = value.join(',');
                        var length1 = context.dataset.data.length;
                        return ((context.dataIndex == (length1 / 2))) ? "$" + value : '';
                    }
                }
            }
        },

        scales: {
            x: {
                ticks: {
                    callback: function (value) {
                        let valueLegend = this.getLabelForValue(value);
                        var date = moment(valueLegend, "MM").format('MMM');
                        return date;
                    },
                },
                grid: {
                    display: false
                },
                beginAtZero: false

            },
            y: {
                beginAtZero: false,
                ticks: {
                    // Include a dollar sign in the ticks
                    callback: function (value) {
                        const valueLegend = this.getLabelForValue(value);
                        var valueLegendRep = valueLegend.replaceAll(',', '');
                            if (valueLegendRep.length <= 3) {
                                return '$' + valueLegendRep;
                            }
                            if (valueLegendRep.length === 4) {
                                return '$' + valueLegendRep.substr(0, 1) + 'k';
                            }
                            if (valueLegendRep.length === 5) {
                                return '$' + valueLegendRep.substr(0, 2) + 'k';
                            }
                            if (valueLegendRep.length === 6) {
                                return '$' + valueLegendRep.substr(0, 3) + 'k';
                            }
                            if (valueLegendRep.length === 7) {
                                return '$' + valueLegendRep.substr(0, 4) + 'k';
                            }
                    }
                },
                title: {
                    display: true,
                    text: title,
                    font: {
                        weight: "bold",
                        size:"10px"
                    },
                },
                grid: {
                    display: false
                }
            }
        },

    };

    const lineChart = (
        <Line
            data={linedata} height="50px" options={option}
        />
    );
    return lineChart;    
};

export default LineChartTrends;
