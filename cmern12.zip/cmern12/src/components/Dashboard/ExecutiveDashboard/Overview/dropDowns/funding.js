import * as React from 'react';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import ListItemText from '@mui/material/ListItemText';
import Select from '@mui/material/Select';
import Checkbox from '@mui/material/Checkbox';
import { Tooltip } from '@mui/material';
import ClearIcon from "@mui/icons-material/Clear";
import IconButton from "@mui/material/IconButton";

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
    PaperProps: {
        style: {
            maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
            width: 250,
            marginLeft: 10,
        },
    },
};
const defaultValue = 'All';
const traverse = (arr, output) => {
    for (let item of arr) {
        output.push(item.label);
        if (item.children) {
            output = traverse(item.children, output);
        }
    }
    return output
}
export default function Funding({disabled, dataArray, setFundingType,setFundingClass, lob, mbuClass, sa, product }) {
    const [checked, setChecked] = React.useState([defaultValue]);
    const [selectedArrayValue, setSelectedArrayValue] = React.useState([]);
    const [selectedParentName, setSelectedParentName] = React.useState([defaultValue]);
    const [all, setAll] = React.useState([]);

    const handleToggle =
        (value, label, id, children, selectedParentObj, selectedObj) => () => {
            const currentIndex = checked.indexOf(label);
            let newChecked = [...checked];
            let value = [...selectedArrayValue];
            if (label !== 'All') {
                newChecked = newChecked.filter(x => x !== 'All')
            } else {
                newChecked = []
            }
            if (currentIndex === -1) {               
                if (label === 'All') {
                    newChecked.push(label);
                    value = [];
                    setSelectedParentName([]);
                } else {
                    const selectedParentValue = selectedParentObj.label
                        ? selectedParentObj.label
                        : '';
                    newChecked.push(label);
                    value.push(selectedObj.value);
                    setSelectedParentName(selectedParentValue);
                }
            } else {
                newChecked.splice(currentIndex, 1);
                value = value.filter(x => x !== selectedObj.value)
                if (newChecked.length === 0) {
                    newChecked = ['All']
                    setFundingClass([]);
                    setFundingType([]);
                }
            }
            setChecked(newChecked);
            setSelectedArrayValue(value);
            setSelectedParentName(selectedParentObj.label);
        };
    React.useEffect(() => {
        let values = traverse(dataArray, [])
        setAll(values)
    }, [dataArray])

    React.useEffect(() => {
        setFundingClass([defaultValue]);
        setFundingType([defaultValue]);
        setChecked([defaultValue]);
        setSelectedArrayValue([]);
    }, [lob]);

    React.useEffect(() => {
        setFundingClass([defaultValue]);
        setFundingType([defaultValue]);
        setChecked([defaultValue]);
        setSelectedArrayValue([]);
    }, [disabled]);

    React.useEffect(() => {
        if (selectedArrayValue.length === 0) {
            setFundingType([defaultValue]);
            setFundingClass([defaultValue]);
        } else {
            setFundingClass(selectedArrayValue);
            setFundingType(selectedArrayValue);
        }
    }, [selectedArrayValue]);

    const handleClearClick = () => {
        setFundingClass([defaultValue]);
        setFundingType([defaultValue]);
        setChecked([defaultValue]);
        setSelectedArrayValue([]);
    };

    return (
        <div>
            <FormControl variant="standard" className = "formControlWidth" sx={{ m: 1}} size="small">
                <InputLabel id="product-label" className="formControlWidthLabel"><span className="fontDisplay">Funding</span></InputLabel>
                <Select
                    labelId="product-label"
                    id="product-state"
                    disabled={disabled}
                    multiple
                    value={dataArray}
                    sx={{ "& .MuiSelect-iconStandard": { right: "20px" }, "& .MuiMenu-paper": { left: "165px" } }}
                    style={{ fontSize: '12px' }}
                    renderValue={() => checked.join(', ')}
                    endAdornment={<IconButton sx={{ padding: '0px' }} onClick={() => handleClearClick()}>
                        <Tooltip title={"Clear filter"}>
                            <ClearIcon sx={{ height: '.7em', width: '.7em' }} />
                        </Tooltip>
                    </IconButton>}
                    MenuProps={MenuProps}
                >
                    {dataArray.map((value, id) => {
                        return (
                            <ToggleList
                                key={id}
                                item={value}
                                id={id}
                                parentObj={value}
                                handleToggle={handleToggle}
                                checked={checked}
                            />
                        );
                    })}
                </Select>
            </FormControl>
        </div>
    );
}
function ToggleList({ id, item, handleToggle, parentObj, checked }) {
    const [show, setShow] = React.useState(false);
    const handleShow = () => {
        setShow((show) => !show);
    };
    return (
        <div
            style={{
                display: 'inline',
            }}
        >
            {' '}
            {item.children?.length ? (
                <span
                    style={{
                        position: 'relative',
                        cursor: 'pointer',
                        float: 'left',
                        left: '14px',
                        top: '5px',
                        zIndex: '1',
                    }}
                    onClick={handleShow}
                >
                    {show ? '-' : '+'}
                </span>
            ) : null}
            <MenuItem
                key={id}
                value={item.label}
                onClick={handleToggle(
                    item.value,
                    item.label,
                    id,
                    item.children,
                    parentObj,
                    item
                )}
            >
               <Checkbox size="small" style={{padding:'0 9px'}} checked={checked.indexOf(item.label) > -1} />
                
                <ListItemText primaryTypographyProps={{fontSize: '14px'}}  primary={item.label} />
            </MenuItem>
            <div
                style={{
                    marginLeft: '28px',
                }}
            >
                {show &&
                    item.children.length &&
                    item.children.map((values, ids) => (
                        <ToggleList
                            key={ids}
                            item={values}
                            id={ids}
                            parentObj={parentObj}
                            handleToggle={handleToggle}
                            checked={checked}
                        />
                    ))}
            </div>
        </div>
    );
}
