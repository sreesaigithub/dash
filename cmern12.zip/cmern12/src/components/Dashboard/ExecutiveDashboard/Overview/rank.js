import React from 'react';


export default function Rank (props) { 
    return (
<div>
<div  >
        <span style={{fontSize:'12px', color:'grey'}}> Rank(1-{props?.ending})</span>
       </div>
       <div style={{alignItems:'right'}} className="circle">
         <span class="text">{props?.value}</span>
       </div>
</div>
       

    );
}