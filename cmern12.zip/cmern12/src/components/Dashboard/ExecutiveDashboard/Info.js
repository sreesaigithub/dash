import { Divider } from '@mui/material';
import * as React from 'react';
import './Info.css';

export default function Info() {
  return (
    <div>
      <div>
        <span style={{ fontSize: '25px', padding: '5px' }}>Info</span>
      </div>
      <Divider />

      <div className="tableScroll">
        <table className="tableScroll">
          <tr>
            <th className="columnWidth"> Cmrcl </th>
            <th className="columnWidth">Mcaid</th>
            <th className="columnWidth">Mcare</th>
            <th className="columnWidth">FGS</th>
            <th>Detailed Usage Information</th>
          </tr>
          <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td className="tabletitle">LOB</td>
          </tr>
          <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td>fgj</td>
          </tr>
          <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td>vnnn</td>
          </tr>
          <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td className="tabletitle">LOB</td>
          </tr>
          <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td>vvvv</td>
          </tr>
          <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td>ghn</td>
          </tr>
          <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td className="tabletitle">LOB</td>
          </tr>
          <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td>fggh</td>
          </tr>       
                    
        </table>
      </div>
    </div>
  );
}

