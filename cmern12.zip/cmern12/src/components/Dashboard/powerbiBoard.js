import React from "react";

// const iframe =
//   '<iframe src="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Cost%20of%20Care%20Platform?rs:embed=true" width="100%" height="600"></iframe>';
const iframe =
  '<iframe src="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Executive%20Dashboards/Executive%20Dashboard%20Commercial?rs:embed=true" width="100%" height="600"></iframe>';

function Iframe(props) {
  return (
    <div
      dangerouslySetInnerHTML={{ __html: props.iframe ? props.iframe : "" }}
    />
  );
}

function PowerbiBoard() {
  return (
    <div>
      <Iframe iframe={iframe} />,
    </div>
  );
}

export default PowerbiBoard;
