import React from "react";
import { useSelector } from "react-redux";
import commercial from "../../../Images/COC-Commercial.png";
import Medicaid from "../../../Images/COC-Medicaid.png";
import Medicare from "../../../Images/COC-Medicare.png";
import COCFGS from "../../../Images/COC-FGS.png";
import Excel from "../../../Images/COC-Excel.png";

function COCOncology() {
  const tierName = useSelector((state) => state.authReducer.tierName);
  const tierLevel = useSelector((state) => state.authReducer.tierLevel);
  return (
    <>
      <div
        className={`icon-wrapper coconcologyCareWrapper ${
          tierName === "COC_Oncology" && tierLevel === 3 ? "d-flex" : "d-none"
        }`}
      >
        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Oncology/Cost%20of%20Care%20Oncology%20Commercial?rs:embed=true"
            target="_blank"
          >
            <img src={commercial} alt="COC Oncology Commercial Icon" />
            <span>Commercial</span>
          </a>
        </div>

        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Oncology/Cost%20of%20Care%20Oncology%20Medicaid?rs:embed=true"
            target="_blank"
          >
            <img src={Medicaid} alt="COC Oncology Medicaid Icon" />
            <span>Medicaid</span>
          </a>
        </div>

        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Oncology/Cost%20of%20Care%20Oncology%20Medicare?rs:embed=true"
            target="_blank"
          >
            <img src={Medicare} alt="COC Oncology Medicare Icon" />
            <span>Medicare</span>
          </a>
        </div>

        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Oncology/Cost%20of%20Care%20Oncology%20FGS?rs:embed=true"
            target="_blank"
          >
            <img src={COCFGS} alt="COC Oncology FGS Icon" />
            <span>FGS</span>
          </a>
        </div>

        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/browse/Oncology/Oncology%20Excel%20Pivots"
            target="_blank"
          >
            <img src={Excel} alt="COC Oncology Excel Icon" />
            <span>Excel Pivot</span>
          </a>
        </div>
      </div>
    </>
  );
}

export default COCOncology;
