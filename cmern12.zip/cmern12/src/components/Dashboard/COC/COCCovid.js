import React from "react";
import { useSelector } from "react-redux";
import commercial from "../../../Images/COC-Commercial.png";
import Medicaid from "../../../Images/COC-Medicaid.png";
import Medicare from "../../../Images/COC-Medicare.png";
import Excel from "../../../Images/COC-Excel.png";

function COCCovid() {
  const tierName = useSelector((state) => state.authReducer.tierName);
  const tierLevel = useSelector((state) => state.authReducer.tierLevel);
  return (
    <>
      <div
        className={`icon-wrapper coccovidCareWrapper ${
          tierName === "COC_Covid" && tierLevel === 3 ? "d-flex" : "d-none"
        }`}
      >
        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Covid%2019%20Dashboards/Covid%2019%20Commercial%20Dashboard?rs:embed=true"
            target="_blank"
          >
            <img src={commercial} alt="COC Covid Commercial Icon" />
            <span>Commercial</span>
          </a>
        </div>

        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Covid%2019%20Dashboards/Covid%2019%20Medicaid%20Dashboard?rs:embed=true"
            target="_blank"
          >
            <img src={Medicaid} alt="COC Covid Medicaid Icon" />
            <span>Medicaid</span>
          </a>
        </div>

        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Covid%2019%20Dashboards/Covid%2019%20Medicare%20Dashboard?rs:embed=true"
            target="_blank"
          >
            <img src={Medicare} alt="COC Covid Medicare Icon" />
            <span>Medicare</span>
          </a>
        </div>

        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/browse/Covid%2019%20Dashboards/Covid%2019%20Dashboard%20Pivot%20Table%20Consolidated%20Workbooks"
            target="_blank"
          >
            <img src={Excel} alt="COC Covid Excel Icon" />
            <span>Excel Pivot</span>
          </a>
        </div>
      </div>
    </>
  );
}

export default COCCovid;
