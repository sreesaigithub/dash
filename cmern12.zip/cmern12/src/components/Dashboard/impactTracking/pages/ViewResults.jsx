import "./viewresults.css";
import Chart from "../pages/chart/Chart";
import { useNavigate } from 'react-router-dom';
import { Button, Box, Tab } from '@mui/material';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import { useEffect, useState } from "react";
import { useSelector, useDispatch } from 'react-redux';
import { downloadWeightData, clearStage1RowData, getImpactStage2Run } from './../../../../redux/actions/ImpackTrackingAction';
import { getParallelAdjustedData, getParallelUnAdjustedData } from "./../../../../redux/actions/ImpackTrackingAction";
import Populationbalance from './grids/Populationbalance';
import Stage2Message from "./widget/Stage2Message";
import { showErrorView, showLoadingView } from "../../../../helper/util";
import { Row } from "react-bootstrap";
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';
import TaskAltOutlinedIcon from '@mui/icons-material/TaskAltOutlined';
import ReportProblemOutlinedIcon from '@mui/icons-material/ReportProblemOutlined';
import ShowViewDetails from "./tables/ShowViewDetails";
import KeyboardDoubleArrowLeftIcon from '@mui/icons-material/KeyboardDoubleArrowLeft';
import KeyboardDoubleArrowRightIcon from '@mui/icons-material/KeyboardDoubleArrowRight';
import Tooltip from '@mui/material/Tooltip';
import CostCurve from "../pages/chart/CostCurve";
import JobInfoHeader from "./tables/JobInfoHeader";

const Single = () => {
  const stage1Data = useSelector((state) => state.impactReducer.stage1RowDataSelected);
  const loading = useSelector((state) => state.authReducer.loading);
  const { analysis_job_id = '', error_code = '', stages = {}, study_group_member_count = 0, control_group_member_count = 0, status = '', jobType = '' } = stage1Data;
  const total_group_member_count = study_group_member_count + control_group_member_count;
  const { stage1 = {}, stage2 = {} } = stages
  const dispatch = useDispatch();
  const navigate = useNavigate();

  let parallelAdjusted = useSelector((state) => state.impactReducer.parallelAdjustedData);
  let parallelUnAdjusted = useSelector((state) => state.impactReducer.parallelUnAdjustedData);
  // let costCurveData = useSelector((state) => state.impactReducer.victCostCurve);

  const goBackHome = () => {
    dispatch(clearStage1RowData());
    navigate('/impacttracking');
  }

  if (analysis_job_id === '') {
    goBackHome();
  }

  useEffect(() => {
    if (analysis_job_id) {
      dispatch(getParallelAdjustedData(analysis_job_id));
      dispatch(getParallelUnAdjustedData(analysis_job_id));
    }
  }, [dispatch, analysis_job_id]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const [modalOpen, setModalOpen] = useState(false);
  const [selectTab, setTabValue] = useState(1);
  const [showResult, setShowResult] = useState(false);
  const [showFlag, setShowFlag] = useState(false);
  const disableImpactFlag = stage2 ? stage2.completion_pct !== 1 : false;
  const disableCursorStyle = disableImpactFlag ? 'not-allowed' : 'pointer';
  const pointerStyle = disableImpactFlag ? 'auto' : '';

  const handleChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const exportCSVData = () => {
    dispatch(downloadWeightData(analysis_job_id));
  };

  function myFunction() {
    if (jobType === 'Complete' && status && status.toUpperCase() !== 'SUCCESS') {
      var popup = document.getElementById("myPopup");
      popup.classList.toggle("show");
    }
  }
  const runStage2 = () => {
    setModalOpen(true);
    dispatch(getImpactStage2Run(analysis_job_id));
  }

  const smTabSize = showFlag ? '100%' : "79%";
  const tabStyling = { padding: '5px 5px 5px 0px' }
  const populationStatusIcon = error_code && error_code.toUpperCase() === 'SMD_FAILURE' ? <ReportProblemOutlinedIcon fontSize="small" sx={{ marginBottom: '4px', color: '#ffca40' }} /> : <TaskAltOutlinedIcon className="completeStyle" fontSize="small" />;
  const displayStyle = ((status && status.toUpperCase() === 'SUCCESS') && (stage2 && stage2.completion_pct === 1)) ? { display: 'none' } : { display: '' };
  let runStage2Btn = null;
  if (error_code && error_code.toUpperCase() === 'SMD_FAILURE') {
    runStage2Btn = (<div className="popup" onMouseEnter={myFunction}>
      <Button variant="contained" disabled className="stage2Option">Run Stage 2</Button>
      <span className="popuptext" id="myPopup">You will not be able to do further Analyses because one or more criteria in population balance are not met. </span>
    </div>);
  } else if (jobType === 'Complete' && (stage1 && stage1.completion_pct === 1) && (stage2 && stage2.completion_pct === 0) && (status && status.toUpperCase() !== 'SUCCESS')) {
    runStage2Btn = <div className="popup">
      <Button variant="contained" disabled className="stage2Option">Run Stage 2</Button>
    </div>;
  } else if (jobType === 'InProgress' && (stage1 && stage1.completion_pct === 1)) {
    runStage2Btn = <div className="popup1" >
      <Button variant="contained" onClick={runStage2} className="stage2Option">Run Stage 2</Button>
      {modalOpen && <Stage2Message setOpenModal={setModalOpen} />}
    </div>;
  }

  return (
    <div className="single">
      {showLoadingView(loading)}
      {showErrorView()}
      <ShowViewDetails show={showResult} populationErrorCode={error_code} onHide={() => setShowResult(false)} showValue={selectTab - 1} />
      <div id='singleContainer' className="singleContainer">
        <JobInfoHeader />
        <Row style={{ margin: `-5px -5px 10px ${showFlag ? '15px' : '25px'}` }}>
          <div style={{ width: '21%' }} className={`shadowEffect ${showFlag ? 'hideSideCount' : ''}`}>
            <TabContext value="1" >
              <TabList aria-label="lab API tabs example" style={{ borderBottom: '1px solid lightgrey' }}>
                <Tab label="Baseline Population" disableRipple sx={{ textTransform: 'capitalize' }} value="1" />
              </TabList>

              <div className="hidePanelResults blueTextColorStyle">
                <Tooltip title={showFlag ? "" : "Hide"} placement="right" arrow>
                  {showFlag ? <KeyboardDoubleArrowRightIcon onClick={() => {
                    setShowFlag(!showFlag);
                  }} /> : <KeyboardDoubleArrowLeftIcon onClick={() => {
                    setShowFlag(!showFlag);
                  }} />}
                </Tooltip>
              </div>

              <TabPanel sx={{ padding: '5px 5px 5px 0px' }} value="1">
                <div className=" totalSMDStyle" >
                  <div className="countContainer" style={{ backgroundColor: '#e0e4ec' }}>
                    <div className="countTitle">TOTAL MEMBERS</div>
                    <div className="countNumber">{total_group_member_count.toLocaleString('en-US', { maximumFractionDigits: 2 })}</div>
                  </div>
                  <div className="countContainer" style={{ backgroundColor: 'transparent' }}>
                    <div className="countTitle">CONTROL GROUP MEMBERS</div>
                    <div className="countNumber">{control_group_member_count.toLocaleString('en-US', { maximumFractionDigits: 2 })}</div>
                  </div>
                  <div className="countContainer" style={{ backgroundColor: 'transparent' }}>
                    <div className="countTitle">STUDY GROUP MEMBERS</div>
                    <div className="countNumber">{study_group_member_count.toLocaleString('en-US', { maximumFractionDigits: 2 })}</div>
                  </div>
                </div>
              </TabPanel>
            </TabContext>
          </div>
          <div style={{ width: smTabSize, marginLeft: '-25px', paddingRight: 5 }}>
            <div className={`showButton blueTextColorStyle ${showFlag ? '' : 'hideResults'}`}>
              <Tooltip title={showFlag ? "Show" : ""} placement="right" arrow>
                {showFlag ?
                  <KeyboardDoubleArrowRightIcon onClick={() => {
                    setShowFlag(!showFlag);
                  }} /> :
                  <KeyboardDoubleArrowLeftIcon onClick={() => {
                    setShowFlag(!showFlag);
                  }} />}
              </Tooltip>
            </div>
            <div className="top shadowEffect" >
              <Box sx={{ width: '100%', typography: 'body1' }}>
                <TabContext value={selectTab} >
                  <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                    <TabList onChange={handleChange} aria-label="lab API tabs example">
                      <Tab sx={{ textTransform: 'capitalize' }} label="Parallel Trend" value={1} />
                      <Tab sx={{ textTransform: 'capitalize' }} label="Population Balance" icon={populationStatusIcon} iconPosition="end" value={2} />
                      <Tab sx={{ textTransform: 'capitalize' }} label="Program Impact" style={{ cursor: disableCursorStyle, pointerEvents: pointerStyle }} disabled={disableImpactFlag} value={3} />
                    </TabList>
                    <div onClick={() => {
                      window.scrollTo(0, 0);
                      setShowResult(!showResult);
                    }} className="viewResults blueTextColorStyle">
                      View Details<KeyboardArrowRightIcon fontSize="small" style={{ marginLeft: -4, marginBottom: 3 }} />
                    </div>
                  </Box>
                  <TabPanel sx={tabStyling} value={1}>
                  <div className="charttitle" style={{ textAlign: 'center' }}>Unweighted and Weighted Baseline Trends</div>
                    <div className="tops">
                      <div className="left">
                        {((parallelUnAdjusted.length !== 0) && (parallelUnAdjusted.Study !== undefined) && (parallelUnAdjusted.Study !== null)) ?
                          <div>
                            <Chart title="Unweighted" height={280} width={380} responsive={true} data={parallelUnAdjusted} />
                          </div> :
                          <div style={{ textAlign: 'center' }}>There are no UnWeighted Chart Data for this Job </div>
                        }
                      </div>
                      <div className="right">
                        {((parallelAdjusted.length !== 0) && (parallelAdjusted.Study !== undefined) && (parallelAdjusted.Study !== null)) ?
                          <div>
                            <Chart title="Weighted" height={280} width={380} responsive={true} data={parallelAdjusted} />
                          </div> :
                          <div style={{ textAlign: 'center' }}>There are no Weighted Chart Data for this Job </div>
                        }
                      </div>
                    </div>
                  </TabPanel>
                  <TabPanel sx={tabStyling} value={2}>
                    <Populationbalance />
                  </TabPanel>
                  <TabPanel sx={tabStyling} value={3}>
                    <div className="topChart">
                      <div className="chart-box">
                        <CostCurve title="Unweighted" height={350} width={600} responsive={true} />
                      </div>
                    </div>
                  </TabPanel>
                </TabContext>
              </Box>
            </div>
          </div>
        </Row>
        <div className="bottom">
          <div class="bottomSpace"><Button variant="outlined" className="gotoOption" onClick={goBackHome}><ArrowBackIosIcon fontSize="small" style={{ marginRight: -4, fontSize: 15, marginBottom: 2 }} />Home Page</Button></div>
          <div class="bottomSpace"> <Button variant="outlined" onClick={exportCSVData} className="downloadOption">Download Weights</Button></div>
          <div class="bottomSpace" style={displayStyle}>
            {runStage2Btn}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Single;