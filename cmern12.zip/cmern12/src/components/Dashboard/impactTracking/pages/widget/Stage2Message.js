import "./Stage2Message.css";
import { React } from "react";
import { useNavigate } from 'react-router-dom';
import {  useDispatch } from 'react-redux';
import {  clearStage1RowData } from './../../../../../redux/actions/ImpackTrackingAction';


function Stage2Message({ setOpenModal }) {
    const dispatch = useDispatch();
    const navigate = useNavigate();
  
    const goBackHome = () => {
      dispatch(clearStage1RowData());
      navigate('/impacttracking');
    }
    
  return (
    <div className="modalBackground">
      <div className="modalContainer">
        <div className="titleCloseBtn">
          <button
            onClick={() => {
              setOpenModal(false);
            }}
          >
            X
          </button>
        </div>
        <div className="titles">
          <p>Second Stage Model Run</p>
        </div>
        <div className="bodys">
          <p>The Second Stage Model Run is in progress. We will notify you once this is completed.</p>
        </div>
        <div className="footers">
          <button onClick={goBackHome}>See Run Status</button>
        </div>
      </div>
    </div>
  );
}

export default Stage2Message;