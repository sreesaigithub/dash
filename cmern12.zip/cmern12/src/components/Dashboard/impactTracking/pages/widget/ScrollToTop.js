import React, { useEffect, useState } from 'react';
import ArrowCircleUpIcon from '@mui/icons-material/ArrowCircleUp';
import Tooltip from '@mui/material/Tooltip';

const ScrollToTop = () => {
    const [showScroll, setShowScroll] = useState(false);
    const checkScrollTop = () => {
        const scrollLimit = 200;
        if (window.pageYOffset > scrollLimit) {
            setShowScroll(true);
        } else if (window.pageYOffset <= scrollLimit) {
            setShowScroll(false);
        }
    };

    const scrollTop = () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
        setShowScroll(false);
    };

    useEffect(() => {
        window.addEventListener('scroll', checkScrollTop);
        return () => window.removeEventListener('scroll', checkScrollTop);
    }, []);
    return (
        <div className="scrollTop" style={{ display: showScroll ? 'flex' : 'none' }} >
            <Tooltip title="Scroll Top" placement="left" arrow>
            <ArrowCircleUpIcon onClick={scrollTop} style={{ height: 40, fontSize: 28}} />
            </Tooltip>
        </div>
    );
}

export default ScrollToTop;