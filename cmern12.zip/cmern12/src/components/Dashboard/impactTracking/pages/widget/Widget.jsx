import "./widget.css";
import { useSelector } from 'react-redux';
import { parseJobsDate } from "../../../../../helper/util";

const Widget = ({ type }) => {
  let data;
  let bgStyle = {};
  const stageFilterData = useSelector((state) => state.impactReducer.stageFilter);
  const valuesFilterVolMemberData = useSelector((state) => state.impactReducer.valuesFilter);
  const valuesVolMemberData = valuesFilterVolMemberData.member_vol;
  let studyMemberCount = valuesVolMemberData.study_group ? valuesVolMemberData.study_group : 0;
  let controlMemberCount = valuesVolMemberData.control_group ? valuesVolMemberData.control_group : 0;
  const caseIdPeriodValue = `${parseJobsDate(stageFilterData.cohort_period_start)} - ${parseJobsDate(stageFilterData.cohort_period_end)}`
  let total = valuesVolMemberData.total ? valuesVolMemberData.total : 0;

  switch (type) {
    case "totalmembers":
      data = {
        title: "TOTAL MEMBERS",
        members: total.toLocaleString('en-US', {maximumFractionDigits:2}),
      };
      bgStyle = { backgroundColor: 'rgb(224, 228, 236)'};
      break;
    case "controlmembers":
      data = {
        title: "CONTROL GROUP MEMBERS",
        members: controlMemberCount.toLocaleString('en-US', {maximumFractionDigits:2}),
      };
      break;
    case "studymembers":
      data = {
        title: "STUDY GROUP MEMBERS",
        members: studyMemberCount.toLocaleString('en-US', {maximumFractionDigits:2}),
      };
      break;
    case "caseidperiod":
      data = {
        title: "CASE ID PERIOD",
        members: caseIdPeriodValue,
      };
      break;
    default:
      break;
  }

  return (
    <div className="widget" style={bgStyle}>
      <div className="widgetleft">
        <span className="widgettitle">{data.title}</span>
        <span className="widgetcounter">
          {data.members}
        </span>
      </div>
    </div>
  );
};

export default Widget;
