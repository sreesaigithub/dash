import "./chart.css";
import { useSelector } from 'react-redux';
import {
  AreaChart,
  Area,
  XAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { VictoryAxis, VictoryChart, VictoryLine, VictoryScatter, VictoryLabel, VictoryVoronoiContainer, VictoryGroup, VictoryTooltip, VictoryLegend } from 'victory';

const Chart = ({ aspect, title, height, width, responsive=false, data}) => {
 
  let group = [];
  group.push(...data.Control);
  const control = [];
   control.push(...data.Study);

  const viewBoxVar = "0 0 " + width +" "+ height;

  const legendInfo = data.LegendInfo;
  const axisRangeX = data.AxisDomainRanges.domainX ;
  const axisRangeY = data.AxisDomainRanges.domainY ;
  let dataSlopeLabelArr = [];
  let a, b, c, d, e, slope, yIntercent, objStartPoint, objEndPoint;
  let infoAngle = [];

  const treadline = (data) => {
      let xSum = 0, ySum = 0, xySum = 0, xSquare = 0, dpsLength = data.length;
      for(var i = 0; i <  dpsLength; ++i){
        xSum += data[i].x;
        ySum += data[i].y;
        xySum += data[i].x * data[i].y;
        xSquare += Math.pow(data[i].x, 2);
      }
      a = xySum * dpsLength;
      b = xSum * ySum;
      c = dpsLength * xSquare;
      d = Math.pow(xSum, 2);

      slope = (a-b) / (c-d);
      console.log("slopse :" + slope);
      e = slope * xSum;

      yIntercent = (ySum - e) / dpsLength;
      // x is the startting of the x on the graph which default 0
      objStartPoint = getTreadPoints(data[0].x, slope, yIntercent);
      objEndPoint = getTreadPoints(data[data.length-1].x, slope, yIntercent);
      slopeLabel(slope, yIntercent);
      return [objStartPoint, objEndPoint];
      
  }; 

  const getTreadPoints = (x, slope, yIntercent) => {
        
        let store = {x : x , y: (((slope * x) + yIntercent))}
        if(infoAngle.length === 2){
          infoAngle = [];
        }
        infoAngle.push(store);
        return store;
  }

  const roundUp4Dec = (num) => {
       return (Math.round(num * 10) / 10) 
  }

  const slopeLabel =(slope, yIntercent) =>{
    dataSlopeLabelArr.push( "y= " + roundUp4Dec(slope) +"x + " + roundUp4Dec(yIntercent));

  }

  const labelMonthCount = () => {
    let labelArr = [];
    if(control.length > group.length){
      for(var i = 0; i <  control.length; ++i){
        labelArr.push(control[i].x);
      }
    } else {
      for(var i = 0; i <  group.length; ++i){
        labelArr.push(group[i].x);
      }
    }
    return labelArr;
  }

  return (
    <div className="chart" >
      <VictoryChart 
      
      height={height}
      width={width}
      containerComponent={<VictoryVoronoiContainer responsive={responsive}/>}
      >
   
         <VictoryAxis orientation='bottom' label={"Month"}  domain={axisRangeX} tickValues={labelMonthCount()} style={{ tickLabels: {fontSize: 8, padding: 5, fontFamily:"Arial"}, axisLabel: {fontSize: 8, padding: 18, fontFamily:"Arial"}}}/>
         <VictoryAxis dependentAxis offsetX={50} label={"Impactable PMPM"} orientation="left" domain={axisRangeY} style={{ tickLabels: {fontSize: 8, padding: 3, fontFamily:"Arial"}, axisLabel: {fontSize: 8, padding: 30, fontFamily:"Arial"}}} />
         <VictoryLine 
            labels={({ datum }) => `PMPM Control: ${datum.y}`}
            labelComponent={              
              <VictoryTooltip
              style={{ fontSize: 10 }}
            />
            }
         data={group} style={{data : {stroke: "#1a3673"}}} />
         
            <VictoryLine data={treadline(group)}  
              labelComponent={
                  <VictoryLabel textAnchor="end"  />
              }
            
              style={{data : {stroke: "#1a3673", strokeDasharray:"6,2"}, labels:{fill: "#1a3673"}}}
              
              />
         
         
         <VictoryLine data={control} style={{data : {stroke: "#f48b49"}}}
         labels={({ datum }) => `PMPM Study: ${datum.y}`}
         labelComponent={              
           <VictoryTooltip
           style={{ fontSize: 10 }}
         />
         }
         />
            <VictoryGroup data={treadline(control)}
            color="#c43a31"
            style={{data : {stroke: "#f48b49"}}} 
            >
          
            <VictoryLine 
                
            style={{data : {stroke: "#f48b49", strokeDasharray:"6,2"}, labels:{fill: "#f48b49"}}}/> 
            </VictoryGroup>
            <VictoryLegend x={0} y={0}
  title={title}
  titleOrientation="top"
  gutter={20}
  orientation="horizontal"
  style={{ title: { fontSize: 12, fontFamily:"Arial"}, labels: {fontSize: 8, fontFamily:"Arial"} }}
  data={[
    { name: "Study : " + dataSlopeLabelArr[1], symbol: {fill: "#f48b49"} }, { name: "Control : " + dataSlopeLabelArr[0], symbol: {fill: "#1a3673"} }
  ]}
/>
      </VictoryChart>
    </div>
  );
  };


export default Chart;
