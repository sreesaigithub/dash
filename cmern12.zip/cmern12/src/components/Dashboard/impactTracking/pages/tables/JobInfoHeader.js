import React from 'react';
import { useSelector } from 'react-redux';
import { parseJobsDate } from '../../../../../helper/util';

const JobInfoHeader = ({headerClass = ''}) => {
    const stage1Data = useSelector((state) => state.impactReducer.stage1RowDataSelected);
    const { analysis_job_id = '', criteria = {} } = stage1Data;
    return (
        <div className={`widgets shadowEffect ${headerClass}`}>
          <div className="jobstatusCell resultFilterStyle">
            <div className="rowHeaderStyle">Job Id</div>
            <div className="rowHeaderValueStyle">{analysis_job_id}</div>
          </div>
          <div className="jobstatusCell resultFilterStyle">
            <div className="rowHeaderStyle">Program Name</div>
            <div className="rowHeaderValueStyle">{criteria.program_name}</div>
          </div>
          <div className="jobstatusCell resultFilterStyle">
            <div className="rowHeaderStyle">LOB</div>
            <div className="rowHeaderValueStyle">{criteria.lob}</div>
          </div>
          <div className="jobstatusCell resultFilterStyle">
            <div className="rowHeaderStyle">Sub LOB</div>
            <div className="rowHeaderValueStyle">{criteria.sub_lob}</div>
          </div>
          <div className="jobstatusCell resultFilterStyle">
            <div className="rowHeaderStyle">Region</div>
            <div className="rowHeaderValueStyle">{criteria.region}</div>
          </div>
          <div className="jobstatusCell resultFilterStyle">
            <div className="rowHeaderStyle">Funding Type</div>
            <div className="rowHeaderValueStyle">{criteria.funding_type}</div>
          </div>
          <div className="jobstatusCell resultFilterStyle">
            <div className="rowHeaderStyle">Case Id Period</div>
            <div className="rowHeaderValueStyle">{parseJobsDate(criteria.cohort_period_start)} - {parseJobsDate(criteria.cohort_period_end)}</div>
          </div>
          <div className="jobstatusCell resultFilterStyle">
            <div className="rowHeaderStyle">Follow Up Period</div>
            <div className="rowHeaderValueStyle">{criteria.follow_up_period} Months</div>
          </div>
        </div>
    );
}

export default JobInfoHeader;