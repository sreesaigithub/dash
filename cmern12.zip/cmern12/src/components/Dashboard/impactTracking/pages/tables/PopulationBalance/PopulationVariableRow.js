import React from 'react';
import AddOutlinedIcon from '@mui/icons-material/AddOutlined';
import { IconButton } from '@mui/material';
import PopulationChildrenRow from './PopulationChildrenRow';
import { TABLE_INTENT_SPACE } from '../../../../../../helper/constants';

export default function PopulationVariableRow({ row = {}, hideRow = false, stageLevel = 0, expandAll }) {
    const { variables } = row;
    const leftStyle = 5 * stageLevel;
    const setValue = (value = '', type = '') => {
        let formatValue = '';
        if(value || value === 0) {
            if(type === "PCT") {
                formatValue = `${Math.round(value * 100)}%`;
            } else {
                formatValue = value.toLocaleString('en-US', { maximumFractionDigits: 2 });
            }
        } else {
            formatValue = value;
        }
        return formatValue;
    };
    
    const variableRows = variables.map((variablesRow, index) => {
        const { display_name = '', measure_type = '', unadj_control_mean = '', unadj_study_mean = '', unadj_smd = '', smd_fail = false, adj_control_mean = '', adj_study_mean = '', adj_smd = '', control_med = '', study_med = '', control_sd = '', study_sd = '' } = variablesRow;
        const smdTextColor = smd_fail ? '#FFB800' : '';
        return (<tr className={!hideRow ? 'hideRow' : ''} keyField={`${display_name}_${index}`} >
            <td>
                <div className="variableDisplayName" style={{ paddingLeft: leftStyle }}>
                <IconButton
                    aria-label="expand row"
                    size="small"
                    style={{ fontSize: 8, visibility: 'hidden', marginRight: TABLE_INTENT_SPACE }}
                >
                    <div className="borderOutlineIcon hideChildIcon"><AddOutlinedIcon fontSize="small" /></div>
                </IconButton>
                <div style={{ paddingTop: 3 }}>{display_name}</div>
                </div>
            </td>
            <td align="left" >{measure_type}</td>
            <td align="right" colSpan={3} style={{ padding: 0 }} >
                <div className="populationGroup">
                    <div className="cellBorder popluationChild" style={{ paddingTop: 5 }}>{setValue(unadj_control_mean, measure_type)}</div>
                    <div className="cellBorder popluationChild" style={{ marginLeft: 0, paddingTop: 5 }}>{setValue(unadj_study_mean, measure_type)}</div>
                    <div className="popluationChild smdStyle" style={{ marginLeft: 0, fontWeight: '500', paddingTop: 3 }}>{(unadj_smd !== null || unadj_smd === 0) ? (unadj_smd).toLocaleString('en-US', { maximumFractionDigits: 2 }) : ''}</div>
                </div>
            </td>
            <td align="right" colSpan={3} style={{ padding: 0 }} >
                <div className="populationGroup">
                    <div className="cellBorder popluationChild" style={{ paddingTop: 5 }}>{setValue(adj_control_mean, measure_type)}</div>
                    <div className="cellBorder popluationChild" style={{ marginLeft: 0, paddingTop: 5 }}>{setValue(adj_study_mean, measure_type)}</div>
                    <div className="popluationChild smdStyle" style={{ marginLeft: 0, fontWeight: '500', paddingTop: 3, color: smdTextColor }}>{(adj_smd !== null || adj_smd === 0) ? (adj_smd).toLocaleString('en-US', { maximumFractionDigits: 2 }) : ''}</div>
                </div>
            </td>
            <td align="right" colSpan={2} >
                <div className="populationGroup">
                    <div className="cellBorder popluationChild">{control_med !== null || control_med === 0 ? control_med.toLocaleString('en-US', { maximumFractionDigits: 2 }) : ''}</div>
                    <div className="popluationChild">{study_med !== null || study_med === 0 ? study_med.toLocaleString('en-US', { maximumFractionDigits: 2 }) : ''}</div>
                </div>
            </td>
            <td align="right" colSpan={2} >
                <div className="populationGroup">
                    <div className="cellBorder popluationChild">{control_sd !== null || control_sd === 0 ? (control_sd).toLocaleString('en-US', { maximumFractionDigits: 2 }) : ''}</div>
                    <div className="popluationChild">{study_sd !== null || study_sd === 0 ? (study_sd).toLocaleString('en-US', { maximumFractionDigits: 2 }) : ''}</div>
                </div>
            </td>
        </tr>)
    });

    return [
        variableRows,
        <PopulationChildrenRow hideRow={hideRow} expandAll={expandAll} stageLevel={stageLevel + 1} childrenRows={row.children} />,
    ];
}