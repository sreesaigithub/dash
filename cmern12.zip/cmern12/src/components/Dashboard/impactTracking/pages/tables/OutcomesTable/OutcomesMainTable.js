import "./OutcomesTable.css";
import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Table } from 'react-bootstrap';
import OutcomesGroupRow from "./OutcomesGroupRow";
import { getOutComesTableData } from "../../../../../../redux/actions/ImpackTrackingAction";

export default function OutcomesMainTable({ expandAll = false }) {
    const rows = useSelector((state) => state.impactReducer.outComesTableInfo);
    const stage1Data = useSelector((state) => state.impactReducer.stage1RowDataSelected);
    const { analysis_job_id = '' } = stage1Data;

    const dispatch = useDispatch();

    useEffect(() => {
        dispatch(getOutComesTableData(analysis_job_id));
    }, [analysis_job_id, dispatch]);

    const subHeadingStyle = { paddingLeft: 10 };
    const noSpacing = { padding: 0 };

    return (
        <Table className="OutcomesTableStyle">
            <thead className="stickyHeader" style={{ position: 'sticky', top: 0 }}>
                <th className="headerStyle categoryOutcomeStyle">
                    <div>Category</div>
                </th>
                <th className="headerStyle ">
                    <div className="blueTextSub blueTextColorStyle">
                        <div>Stat</div><div>Sig</div>
                    </div>
                </th>
                <th className="headerStyle rateStyle">
                    <div>
                        Rate Type
                    </div>
                </th>
                <th align="center" className="headerStyle" colSpan="3">
                    <div style={noSpacing}>
                        <div className="">Control Group</div>
                        <div className="outcomeContainer">
                            <div className="outcomeField">Baseline</div>
                            <div className="outcomeField" style={subHeadingStyle}>Performance</div>
                        </div>
                    </div>
                </th>
                <th align="center" className="headerStyle" colSpan="3">
                    <div style={noSpacing}>
                        <div className="">Study Group</div>
                        <div className="outcomeContainer">
                            <div className="outcomeField">Baseline</div>
                            <div className="outcomeField" style={subHeadingStyle}>Performance</div>
                        </div>
                    </div>
                </th>
                <th align="center" className="headerStyle" colSpan="3">
                    <div style={noSpacing}>
                        <div className="">Trend</div>
                        <div className="outcomeContainer">
                            <div className="outcomeField">Study</div>
                            <div className="outcomeField" style={subHeadingStyle}>Control</div>
                        </div>
                    </div>
                </th>
                <th className="headerStyle " style={{ paddingBottom: 9 }}>
                    <div className="blueTextSub blueTextColorStyle">
                        DID
                    </div>
                </th>
                <th className="headerStyle">
                    <div className="blueTextSub blueTextColorStyle">
                        <div>Program</div><div>Impact</div>
                    </div>
                </th>
                <th align="center" className="headerStyle" colSpan="3">
                    <div style={noSpacing}>
                        <div className="blueTextColorStyle blueTextSub">Confidence Interval</div>
                        <div className="outcomeContainer" style={noSpacing}>
                            <div className="outcomeField">Lower</div>
                            <div className="outcomeField" style={subHeadingStyle}>Upper</div>
                        </div>
                    </div>
                </th>
            </thead>
            <tbody>
                <OutcomesGroupRow rows={rows} expandAll={expandAll} />
            </tbody>
        </Table>
    );
}