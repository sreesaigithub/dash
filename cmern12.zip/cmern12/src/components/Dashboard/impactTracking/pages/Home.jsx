import Sidebar from "../pages/sidebar/Sidebar";
import "./home.css";
import Widget from "../pages/widget/Widget";
import Jobstatustable from "../pages/tables/Jobstatustable";
import { useDispatch, useSelector } from 'react-redux';
import { useEffect } from 'react';
import { retrieveJobsInfo, refreshJobsInfo, getImpactDashboardEventsData } from "../../../../redux/actions/ImpackTrackingAction";
import { showErrorView } from "../../../../helper/util";
import ScrollToTop from "./widget/ScrollToTop";
import RefreshIcon from '@mui/icons-material/Refresh';

const Home = () => {
  const inProgressJobs = useSelector((state) => state.impactReducer.inProgressJobsInfo);
  const completedJobs = useSelector((state) => state.impactReducer.completeJobsInfo);
  const dispatch = useDispatch();

  let impactEvents = useSelector((state) => state.impactReducer.refreshEventsData);

  useEffect(() => {
    window.scrollTo(0, 0);
    dispatch(retrieveJobsInfo());
    dispatch(getImpactDashboardEventsData());

    const interval = setInterval(() => {
      dispatch(refreshJobsInfo());
    }, 60000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="home">
      <Sidebar />
      <ScrollToTop />
      {showErrorView()}
      <div className="homeContainer">
        {/* <div className="refresh" >
          <span className="refreshtext"><RefreshIcon/>Last Data Refresh:</span>
        </div> */}
        <div className="widgets" style={{ marginLeft: 10, marginRight: 10 }}>
          <Widget type="totalmembers" />
          <Widget type="controlmembers" />
          <Widget type="studymembers" />
          <Widget type="caseidperiod" />
        </div>
        <div className="listContainer">
          <div className="listTitle">{`IN PROGRESS (${inProgressJobs ? inProgressJobs.length : 0})`}</div>
          {inProgressJobs && inProgressJobs.length === 0 ? <div style={{ textAlign: 'center' }}>There are no Analysis Jobs in "IN PROGRESS" state</div> : <Jobstatustable jobType="InProgress" jobsInfo={inProgressJobs} />}
        </div>
        <div className="listContainer">
          <div className="listTitle">{`COMPLETED (${completedJobs ? completedJobs.length : 0})`}</div>
          {completedJobs && completedJobs.length === 0 ? <div style={{ textAlign: 'center' }}>There are no Analysis Jobs in "COMPLETED" state</div> : <Jobstatustable jobType="Complete" jobsInfo={completedJobs} />}
        </div>
      </div>
    </div>
  );
};

export default Home;
