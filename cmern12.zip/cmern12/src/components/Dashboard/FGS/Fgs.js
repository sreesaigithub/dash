import React from "react";
import { useSelector } from "react-redux";
import Excel from "../../../Images/COC-Excel.png";
import executive from "../../../Images/COC-Executive.png";
import COCRFA from "../../../Images/COC-Restated-Financial.png";
import COCVisualIcon from "../../../Images/COC-Visual.png";

import COCMatrixIcon from "../../../Images/COC-Matrix.png";
import COCCovidIcon from "../../../Images/COC-Covid.png";
import COCClinicIcon from "../../../Images/COC-Clinic.png";
import COCOncologyIcon from "../../../Images/COC-Oncology.png";
import Specialty from "../../../Images/COC-Speciality-Pharmacy.png";
import Capitation from "../../../Images/COC-Capitation.png";
function Fgs() {
  const tierName = useSelector((state) => state.authReducer.tierName);
  const tierLevel = useSelector((state) => state.authReducer.tierLevel);
  return (
    <>
      <div
        className={`icon-wrapper FGSDashboardWrapper align-items-start ${
          tierName === "FGS" && tierLevel === 2 ? "d-flex" : "d-none"
        }`}
      >
        <div className="FGSCoC mb-5 pb-3">
          <h4 style={{ color: "#1a3673" }}>Cost OF Care</h4>
          <div className="icon-wrapper">
            <div className="icon">
              <a
                href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Cost%20of%20Care%20Dashboards/Cost%20of%20Care%20FGS?rs:embed=true"
                target="_blank"
                className="mb-2"
              >
                <img src={COCVisualIcon} alt="COC Visual FGS Icon" />
                <span>
                  Cost Of Care <br />
                  Visual
                </span>
              </a>

              <a
                href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/browse/Cost%20of%20Care%20Dashboards/Cost%20of%20Care%20Excel%20Pivot%20Tables"
                target="_blank"
              >
                <img
                  src={Excel}
                  alt="COC Visual Excel Icon"
                  className="excelicon"
                />
                <span className="exceltxt">Excel Pivot</span>
              </a>
            </div>
            <div className="icon">
              <a
                href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Cost%20of%20Care%20Matrix%20Reports/Cost%20of%20Care%20Matrix%20FGS?rs:embed=true"
                target="_blank"
                className="mb-2"
              >
                <img src={COCMatrixIcon} alt="COC Matrix FGS Icon" />
                <span>
                  Cost Of Care <br />
                  Matrix
                </span>
              </a>
            </div>

            <div className="icon">
              <a
                href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Clinical%20Conditions/COC%20FGS%20Clinical%20Conditions?rs:embed=true"
                target="_blank"
                className="mb-2"
              >
                <img src={COCClinicIcon} alt="COC Clinical FGS Icon" />
                <span>
                  Clinical <br />
                  Conditions
                </span>
              </a>

              <a
                href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/browse/Clinical%20Conditions/Clinical%20Condition%20Excel%20Pivots"
                target="_blank"
              >
                <img
                  src={Excel}
                  alt="COC Clinical Excel Icon"
                  className="excelicon"
                />
                <span className="exceltxt">Excel Pivot</span>
              </a>
            </div>

            <div className="icon">
              <a
                href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Oncology/Cost%20of%20Care%20Oncology%20FGS?rs:embed=true"
                target="_blank"
                className="mb-2"
              >
                <img src={COCOncologyIcon} alt="COC Oncology FGS Icon" />
                <span>
                  Oncology
                  <br />
                  &nbsp;
                </span>
              </a>

              <a
                href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/browse/Oncology/Oncology%20Excel%20Pivots"
                target="_blank"
              >
                <img
                  src={Excel}
                  alt="COC Oncology Excel Icon"
                  className="excelicon"
                />
                <span className="exceltxt">Excel Pivot</span>
              </a>
            </div>
          </div>
        </div>

        <div className="FGSOther me-4 ms-4 pb-3">
          <h4 style={{ color: "#1a3673" }}>Other</h4>
          <div className="icon-wrapper">
            <div className="icon">
              <a
                href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/SpecialtyRx/SpecialtyRx_Dashboard?rs:embed=true"
                target="_blank"
                className="mb-2"
              >
                <img src={Specialty} alt="Specialty Pharmacy Icon" />
                <span>
                  Specialty <br />
                  Pharmacy
                </span>
              </a>

              <a
                href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/browse/SpecialtyRx"
                target="_blank"
              >
                <img
                  src={Excel}
                  alt="SpecialtyRx Excel Icon"
                  className="excelicon"
                />
                <span className="exceltxt">Excel Pivot</span>
              </a>
            </div>
            <div className="icon">
              <a
                href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Capitation%20Dashboards/Capitation%20FGS?rs:embed=true"
                target="_blank"
                className="mb-2"
              >
                <img src={Capitation} alt="Capitation FGS Icon" />
                <span>
                  Capitation
                  <br />
                  &nbsp;
                </span>
              </a>
              <a
                href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/browse/Capitation%20Dashboards/Capitation%20Excel%20Pivot%20Tables"
                target="_blank"
              >
                <img
                  src={Excel}
                  alt="Capitation Excel Icon"
                  className="excelicon"
                />
                <span className="exceltxt">Excel Pivot</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Fgs;
