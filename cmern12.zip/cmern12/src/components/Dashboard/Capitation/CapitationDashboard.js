import React from "react";
import { useSelector } from "react-redux";
import commercial from "../../../Images/COC-Commercial.png";
import Medicaid from "../../../Images/COC-Medicaid.png";
import Medicare from "../../../Images/COC-Medicare.png";
import COCFGS from "../../../Images/COC-FGS.png";
import Excel from "../../../Images/COC-Excel.png";

function CapitationDashboard() {
  const tierName = useSelector((state) => state.authReducer.tierName);
  const tierLevel = useSelector((state) => state.authReducer.tierLevel);

  return (
    <>
      <div
        className={`icon-wrapper CapitationDashboardWrapper ${
          tierName === "Capitation" && tierLevel === 2 ? "d-flex" : "d-none"
        }`}
      >
        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Capitation%20Dashboards/Capitation%20Commercial?rs:embed=true"
            target="_blank"
          >
            <img src={commercial} alt="Capitation Commercial Icon" />
            <span>Commercial</span>
          </a>
        </div>

        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Capitation%20Dashboards/Capitation%20Medicaid?rs:embed=true"
            target="_blank"
          >
            <img src={Medicaid} alt="Capitation Medicaid Icon" />
            <span>Medicaid</span>
          </a>
        </div>

        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Capitation%20Dashboards/Capitation%20Medicare?rs:embed=true"
            target="_blank"
          >
            <img src={Medicare} alt="Capitation Medicare Icon" />
            <span>Medicare</span>
          </a>
        </div>

        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Capitation%20Dashboards/Capitation%20FGS?rs:embed=true"
            target="_blank"
          >
            <img src={COCFGS} alt="Capitation FGS Icon" />
            <span>FGS</span>
          </a>
        </div>

        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/browse/Capitation%20Dashboards/Capitation%20Excel%20Pivot%20Tables"
            target="_blank"
          >
            <img src={Excel} alt="Capitation Excel Icon" />
            <span>Excel Pivot</span>
          </a>
        </div>
      </div>
    </>
  );
}

export default CapitationDashboard;
