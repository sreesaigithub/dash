import React from "react";
import Specialty from "../../../Images/COC-Speciality-Pharmacy.png";
import Excel from "../../../Images/COC-Excel.png";
import { useSelector } from "react-redux";

function SpecialityRxDashboard() {
  const tierName = useSelector((state) => state.authReducer.tierName);
  const tierLevel = useSelector((state) => state.authReducer.tierLevel);

  return (
    <>
      <div
        className={`icon-wrapper SpecialityRxDashboardWrapper ${
          tierName === "SpecialtyRx" && tierLevel === 2 ? "d-flex" : "d-none"
        }`}
      >
        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/SpecialtyRx/SpecialtyRx_Dashboard?rs:embed=true"
            target="_blank"
          >
            <img src={Specialty} alt="Specialty Pharmacy Icon" />
            <span>Specialty Pharmacy</span>
          </a>
        </div>

        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/browse/SpecialtyRx"
            target="_blank"
          >
            <img src={Excel} alt="SpecialtyRx Excel Icon" />
            <span>Excel Pivot</span>
          </a>
        </div>
      </div>
    </>
  );
}

export default SpecialityRxDashboard;
