﻿import React, { useState, useEffect } from "react";
import axios from "axios";
import { useSelector } from "react-redux";
//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables";
import "datatables.net-dt/css/jquery.dataTables.min.css";
import $ from "jquery";
//jQuery libraries
import "jquery/dist/jquery.min.js";
import ModalBox from "../../Utility/ModalBox";
import { useHistory } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import Spinner from "../../Dashboard/ExecutiveDashboard/Overview/spinner";

import "./Users.css";
//import EditUserInAdmin from"../AdminOperations/EditUserInAdmin"

export default function Users() {
  const [activeTab, setActiveTab] = useState("devaTabApprovalRequest");
  const [approvalRequestData, setApprovalRequestData] = useState([]);
  const [approvalHistoryData, setApprovalHistoryData] = useState([]);
  const [processedUser, setProcessedUser] = useState([]);
  const [textBox, setTextBox] = useState("");
  const [show, setShow] = useState(false);
  const [parentModalData, setParentModalData] = useState({});
  const [denyMdl, setDenyMdl] = useState(false);
  const userData = useSelector((state) => state.authReducer.user);
  const [loadingMaster, setLoadingMaster] = useState(false);

  let activatedTab;
  let myUsertable;
  let approvalTable;
  let approvalButtonid;
  let extraTable;
  let tableReInitialize = true;
  let modalBoxValue;
  let navigate = useNavigate();

  //const baseUrl = process.env.REACT_APP_BASE_API_URL;
  //const baseUrl = "http://localhost:8080/cocwp/api";
  const baseUrl = window.__RUNTIME_CONFIG__.REACT_APP_BASE_API_USER_MGNT_URL;

  const activeTabDeva = (id) => {
    setActiveTab(id);
  };

  useEffect(() => {
    if (activeTab === "devaTabHome") {
      ProcessedUsergrid();
    }
    if (activeTab === "devaTabApprovalRequest") {
      ApprovalRequestgrid();
    }
    if (activeTab === "devaTabApprovalHistory") {
      ApprovalHistorygrid();
    }
  }, [activeTab, userData.userId]);

  const approveButton = (approvalButtonid) => {
    console.log(textBox);
    let approverComments = textBox;
    if (approverComments == "") {
      setParentModalData({
        title: "Approvals !!!",
        content: "Please enter approver comments under comments section",
      });
      setShow(true);
      // axios
      //   .get("/Admin/NoApproverCommentModal")
      //   .then((res) => setParentModalData(res.data), setShow(true));
      //window.location.reload();
    } else {
      axios
        .get(
          `${baseUrl}/users/approveUser?registrationId=${approvalButtonid}&approverComments=${approverComments}
        `
        )
        .then((res) => {
          console.log(res);
          setParentModalData({
            title: "Approvals !!!",
            content: res.data,
          });
          setShow(true);

          setApprovalRequestData(
            approvalRequestData.filter(
              (user) => user.REGISTRATION_ID !== approvalButtonid
            )
          );
        });
    }
  };

  const denyButton = (approvalButtonid) => {
    let approverComments = textBox;
    console.log(textBox);
    if (approverComments == "") {
      setParentModalData({
        title: "Deny Registration",
        content: "Please add denial reason under comments section.",
      });
      setShow(true);
      setDenyMdl(true);
    } else {
      axios({
        method: "post",
        url: `${baseUrl}/users/denyUser?registrationId=${approvalButtonid}&approverComments=${approverComments}`,
      }).then((response) => {
        setParentModalData({
          title: "Deny Registration",
          content: "User denied successfully",
        });
        setShow(true);
        setDenyMdl(true);
        setApprovalRequestData(
          approvalRequestData.filter(
            (user) => user.REGISTRATION_ID !== approvalButtonid
          )
        );
      });
    }
  };

  const ProcessedUsergrid = () => {
    setLoadingMaster(true);
    axios
      .get(`${baseUrl}/users/ProcessedUsers?userid=${userData.userId}`)
      .then((res) => {
        setProcessedUser(res.data);
        $("#ProcessedUserRequest").DataTable().destroy();
        if (tableReInitialize) {
          tableReInitialize = false;
          setTimeout(function () {
            myUsertable = $("#ProcessedUserRequest").DataTable({
              paging: true,
              sort: false,
              searching: true,
            });
          }, 1000);
          setLoadingMaster(false);
        }
      });
  };

  const ApprovalRequestgrid = () => {
    setLoadingMaster(true);
    axios
      .get(`${baseUrl}/users/ApprovalRequest?userid=${userData.userId}`)
      .then((res) => {
        setApprovalRequestData(res.data);
        $("#approveRequest").DataTable().destroy();
        if (tableReInitialize) {
          tableReInitialize = false;
          setTimeout(function () {
            extraTable = $("#approveRequest").DataTable({
              paging: true,
              sort: false,
              searching: true,
            });
          }, 1000);
          setLoadingMaster(false);
        }
      });
  };

  const ApprovalHistorygrid = () => {
    setLoadingMaster(true);
    axios
      .get(`${baseUrl}/users/ApprovalHistory?userid=${userData.userId}`)
      .then((res) => {
        setApprovalHistoryData(res.data);
        $("#ApprovalHistoryRequest").DataTable().destroy();
        if (tableReInitialize) {
          tableReInitialize = false;
          setTimeout(function () {
            approvalTable = $("#ApprovalHistoryRequest").DataTable({
              paging: true,
              sort: false,
              searching: true,
            });
          }, 1000);
          setLoadingMaster(false);
        }
      });
  };

  const handleInputChange = (e) => {
    setTextBox(e.target.value);
  };

  const closeModal = () => {
    setShow(false);
  };

  const EditFunctionality = (id) => {
    navigate("../devops/adminops/users/EditUserInAdmin", { state: { id: id } });
  };

  const DeleteFunctionality = (id) => {
    axios.delete(`${baseUrl}/users/${id}`).then((res) => {
      setParentModalData(res.data);
      setShow(true);
      if (res.data.title === "Success!") {
        setProcessedUser(
          processedUser.filter((prcesuser) => prcesuser.USERID != id)
        );
      }
    });
  };
  return (
    <>
      {loadingMaster ? (
        <Spinner>
          <i className="fa fa-spinner" aria-hidden="true"></i>
        </Spinner>
      ) : (
        <div className="user-wrapper">
          <div>
            <div className="float-left">
              <h3>Users</h3>
            </div>
          </div>

          <div className="clear">
            <div className="float-left multi-tabs">
              <ul className="nav nav-tabs border-0">
                <li className="nav-item">
                  <a
                    className={`nav-link ${
                      activeTab === "devaTabApprovalRequest"
                        ? "active show"
                        : ""
                    }`}
                    id="devaTabApprovalRequest"
                    data-toggle="pill"
                    href="#ApprovalRequests"
                    onClick={() => activeTabDeva("devaTabApprovalRequest")}
                  >
                    Approval Requests
                  </a>
                </li>
                <li className="nav-item">
                  <a
                    className={`nav-link ${
                      activeTab === "devaTabApprovalHistory"
                        ? "active show"
                        : ""
                    }`}
                    data-toggle="pill"
                    id="devaTabApprovalHistory"
                    href="#ApprovalHistory"
                    onClick={() => activeTabDeva("devaTabApprovalHistory")}
                  >
                    Approval History
                  </a>
                </li>
                <li className="nav-item">
                  <a
                    className={`nav-link ${
                      activeTab === "devaTabHome" ? "active show" : ""
                    }`}
                    data-toggle="pill"
                    id="devaTabHome"
                    href="#Home"
                    onClick={() => activeTabDeva("devaTabHome")}
                  >
                    Processed users
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div id="PlaceHolderCreateEditDelete"></div>

          <div className="tab-content users-table clear">
            <div
              id="devaTabApprovalRequestDiv"
              className={`tab-pane ${
                activeTab === "devaTabApprovalRequest" ? "active in show" : ""
              }`}
            >
              <br />
              <table
                id="approveRequest"
                className="table table-wrapper glb-table"
              >
                <thead>
                  <tr className="text-center">
                    <th>User Id</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Plan Name</th>
                    <th>Role Name</th>
                    <th>Access Type</th>
                    <th>Business Justification</th>
                    <th>Email Address</th>
                    <th>Date</th>
                    <th></th>
                    <th></th>
                    <th>Comments</th>
                  </tr>
                </thead>
                <tbody>
                  {approvalRequestData.length > 0 &&
                    approvalRequestData.map((dt) => {
                      return (
                        <tr key={dt.userid}>
                          <td>{dt.USERID}</td>
                          <td>{dt.FIRST_NAME}</td>
                          <td>{dt.LAST_NAME}</td>
                          <td className="text-start1">{dt.PLAN_NAME}</td>
                          <td className="text-start1">{dt.ROLE}</td>
                          <td className="text-center1">{dt.ACCESS_TYPE}</td>
                          <td className="text-center1">
                            {dt.BUINSESS_JUSTIFICATION}
                          </td>
                          <td className="text-center1">
                            {dt.WORK_EMAIL_ID != null ? dt.WORK_EMAIL_ID : ""}
                          </td>
                          <td>{dt.CREATION_DATE}</td>
                          <td>
                            <input
                              type="button"
                              id={dt.REGISTRATION_ID}
                              className="btn-primary user-approval"
                              onClick={() => approveButton(dt.REGISTRATION_ID)}
                              value="Approve"
                            />
                          </td>
                          <td>
                            <input
                              type="button"
                              className="btn-primary user-denial"
                              id={"Deny" + dt.REGISTRATION_ID}
                              onClick={() => denyButton(dt.REGISTRATION_ID)}
                              value="Deny"
                            />
                          </td>
                          <td>
                            <input
                              type="text"
                              id="txtApproverComments"
                              onChange={handleInputChange}
                              required
                            />
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
            <div
              id="devaTabApprovalHistoryDiv"
              className={`tab-pane ${
                activeTab === "devaTabApprovalHistory" ? "active in show" : ""
              }`}
            >
              <br />
              <table
                id="ApprovalHistoryRequest"
                className="table table-wrapper glb-table"
              >
                <thead>
                  <tr>
                    <th>User Id</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Role Name</th>
                    <th>Plan Name</th>
                    <th>Email Address</th>
                    <th>Business Justification</th>
                    <th>Updated Date</th>
                    <th>Access Type</th>
                    <th>Is Approved</th>
                    <th>Is Processed</th>
                    <th>Approver Comments</th>
                  </tr>
                </thead>
                <tbody>
                  {approvalHistoryData.length > 0 &&
                    approvalHistoryData.map((dt) => {
                      return (
                        <tr key={dt.userid}>
                          <td>{dt.USERID}</td>
                          <td>{dt.FIRST_NAME}</td>
                          <td>{dt.LAST_NAME}</td>
                          <td className="text-start1">{dt.ROLE}</td>
                          <td className="text-center1">{dt.PLAN_NAME}</td>
                          <td>
                            {dt.WORK_EMAIL_ID != null ? dt.WORK_EMAIL_ID : ""}
                          </td>
                          <td>{dt.BUINSESS_JUSTIFICATION}</td>
                          <td className="text-start1">{dt.UPDATED_DATE}</td>
                          <td className="text-center1">{dt.ACCESS_TYPE}</td>
                          <td className="text-center1">
                            {dt.IsAPPROVED === "N"
                              ? dt.IsDENIED === "Y"
                                ? "Denied"
                                : "Pending"
                              : "Approved"}
                          </td>
                          <td>
                            {dt.IsPROCESSED === "N"
                              ? dt.IsDENIED === "Y"
                                ? "Denied"
                                : "Pending"
                              : "Approved"}
                          </td>
                          <td>{dt.APPROVER_COMMENTS}</td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
            <div
              id="devaTabHomeDiv"
              className={`tab-pane ${
                activeTab === "devaTabHome" ? "active in show" : ""
              }`}
            >
              <br />
              <table
                id="ProcessedUserRequest"
                className="table table-wrapper glb-table"
              >
                <thead>
                  <tr>
                    <th>User Id</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Role Name</th>
                    <th className="text-center1">Group Name</th>
                    <th>Group Member Role</th>
                    <th>Email Address</th>
                    <th>Active</th>
                    <th>Created On</th>
                    <th>Updated On</th>
                    <th>Edit</th>
                    <th>Delete</th>
                  </tr>
                </thead>
                <tbody>
                  {processedUser.length > 0 &&
                    processedUser.map((dt) => {
                      return (
                        <tr key={dt.USERID}>
                          <td>{dt.USERID}</td>
                          <td>{dt.FIRST_NAME}</td>
                          <td>{dt.LAST_NAME}</td>
                          <td className="text-center1">{dt.ROLE_NAME}</td>
                          <td className="text-center1">{dt.GROUP_NAME}</td>
                          <td>{dt.MBR_ROLE_NAME}</td>
                          <td>{dt.work_EMAIL_ID}</td>
                          <td className="text-center">
                            {dt.IS_ACTIVE === "Yes" ? (
                              <i
                                className="fa fa-check-circle green font16"
                                aria-hidden="true"
                              ></i>
                            ) : (
                              <i className="fa fa-times-circle dark-red font16"></i>
                            )}
                          </td>
                          <td>{dt.CREATION_DATE}</td>
                          <td>{dt.UPDATED_DATE}</td>
                          <td className="text-center">
                            <i
                              className="fa fa-pencil"
                              title="Edit"
                              onClick={() => EditFunctionality(dt.USERID)}
                            ></i>
                          </td>
                          <td>
                            <i
                              className="fa fa-trash"
                              title="Delete"
                              onClick={() => DeleteFunctionality(dt.USERID)}
                            ></i>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </div>

          <ModalBox
            modalShow={show}
            handleClose={closeModal}
            modalData={parentModalData}
          >
            <a
              href="#"
              className="btn btn-success"
              data-dismiss="modal"
              onClick={() => {
                closeModal();
              }}
            >
              OK
            </a>
          </ModalBox>

          {denyMdl && (
            <ModalBox
              modalShow={show}
              handleClose={closeModal}
              modalData={parentModalData}
            >
              <a
                href="#"
                className="btn btn-success"
                data-dismiss="modal"
                onClick={() => {
                  closeModal();
                }}
              >
                OK
              </a>
            </ModalBox>
          )}
        </div>
      )}
    </>
  );
}
