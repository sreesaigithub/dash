import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import ModalBox from "../../Utility/ModalBox";
import { useNavigate } from "react-router-dom";
import Spinner from "../../Dashboard/ExecutiveDashboard/Overview/spinner";
import axios from "axios";

export default function EditGroup() {
  const [show, setShow] = useState(false);
  const [parentModalData, setParentModalData] = useState({});
  const [loadingMaster, setLoadingMaster] = useState(false);
  const [editGroupData, setEditGroupData] = useState({
    GROUP_ID: 0,
    GROUP_NAME: "",
    SHORT_NAME: "",
    POC: "",
    LOGO_IMAGE_NAME: "",
    NOTES: "",
    IS_ACTIVE: "",
    CREATION_DATE: "",
    UPDATED_DATE: "",
    CREATED_BY: "",
    MODIFIED_BY: "",
    GRP_DOMAINS: "",
    LOGO_IMAGE_FORMAT: "",
    LOGO_IMAGE_FILE: "",
    TERMS_OF_USE: "",
    SRC_SYS_DIM_ID: 0,
  });
  let location = useLocation();
  let userIdChange = location.state.id;
  let navigate = useNavigate();

  const handleInputChange = (e) => {
    setEditGroupData({
      ...editGroupData,
      [e.target.name]: e.target.value,
    });
  };

  //    const baseUrl = process.env.REACT_APP_BASE_API_URL;
  const baseUrl = window.__RUNTIME_CONFIG__.REACT_APP_BASE_API_USER_MGNT_URL;
  //const baseUrl ="http://localhost:8080/cocwp/api";
  useEffect(() => {
    setLoadingMaster(true);
    axios
      .get(`${baseUrl}/admin/userGroup?GROUP_ID=${userIdChange}`)
      .then((res) => {
        const userData = res.data;
        setEditGroupData(userData);
        setLoadingMaster(false);
      });
  }, [userIdChange]);

  const updateGroup = (e) => {
    e.preventDefault();
    console.log(editGroupData);
    axios({
      method: "put",
      url: `${baseUrl}/admin/Updategroup/${userIdChange}`,
      data: editGroupData,
    }).then((response) => setParentModalData(response.data), setShow(true));
  };

  const closeModal = () => {
    setShow(false);
  };

  const moveBack = () => {
    setShow(false);
    navigate("../devops/adminops/rolesgroups");
  };
  return (
    <div className="user-wrapper">
      <div className="d-flex justify-content-between align-items-center">
        <div className="float-left">
          <h3>Edit Group
          </h3>
        </div>
        <a className="float-right" onClick={() => navigate("../devops/adminops/rolesgroups")}><i className="fa fa-arrow-circle-left mt-2 font20" aria-hidden="true"></i>Back</a>
      </div>
    <div className="row edituserroles">
      <div className="col-8">
        {loadingMaster ? (
          <Spinner>
            <i className="fa fa-spinner" aria-hidden="true"></i>
          </Spinner>
        ) : (
          <form>
            <div className="form-group row">
              <label className="control-label col-3 col-form-label">
                Group Id
              </label>
              <div className="col-7">
                <input
                  id="groupId"
                  type="text"
                  name="GROUP_ID"
                  value={editGroupData.GROUP_ID}
                  className="form-control"
                  readOnly
                />
              </div>
            </div>
            <div className="form-group row">
              <label className="control-label col-3 col-form-label">
                Group Name
              </label>
              <div className="col-7">
                <input
                  id="groupId"
                  type="text"
                  name="GROUP_NAME"
                  value={editGroupData.GROUP_NAME}
                  className="form-control"
                  onChange={handleInputChange}
                />
              </div>
            </div>
            <div className="form-group row">
              <label className="control-label col-3 col-form-label">
                Group Domains
              </label>
              <div className="col-7">
                <input
                  id="groupId"
                  type="text"
                  name="GRP_DOMAINS"
                  value={editGroupData.GRP_DOMAINS}
                  className="form-control"
                  onChange={handleInputChange}
                />
              </div>
            </div>
            <div className="form-group row">
              <label className="control-label col-3 col-form-label">
                Short Name
              </label>
              <div className="col-7">
                <input
                  id="groupId"
                  type="text"
                  name="SHORT_NAME"
                  value={editGroupData.SHORT_NAME}
                  className="form-control"
                  onChange={handleInputChange}
                />
              </div>
            </div>
            <div className="form-group row">
              <label className="control-label col-3 col-form-label">
                Terms Of Use
              </label>
              <div className="col-7">
                <input
                  id="groupId"
                  type="text"
                  name="TERMS_OF_USE"
                  value={editGroupData.TERMS_OF_USE}
                  className="form-control"
                  onChange={handleInputChange}
                />
              </div>
            </div>
            <div className="form-group row">
              <label className="control-label col-3 col-form-label">
                Is Active
              </label>
              <div className="col-7">
                <input
                  id="groupId"
                  type="text"
                  name="IS_ACTIVE"
                  value={editGroupData.IS_ACTIVE}
                  className="form-control"
                  onChange={handleInputChange}
                />
              </div>
            </div>

            <div className="form-group row col-12 justify-content-center">
              <input
                type="submit"
                value="Save"
                onClick={updateGroup}
                className="btn btn-primary w-25"
              />
            </div>
            <ModalBox
              modalShow={show}
              handleClose={closeModal}
              modalData={parentModalData}
            >
              <a
                href="#"
                className="btn btn-success"
                data-dismiss="modal"
                onClick={() => moveBack()}
              >
                OK
              </a>
            </ModalBox>
          </form>
        )}
      </div>
    
    </div>
    
    </div>
  );
}
