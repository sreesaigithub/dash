import React from "react";

export default function Support() {
  return (
    <>
      <div className="d-flex justify-content-between container home-content">
        <div>
          <div className="mb-4">
            <h3> COC Support </h3>
            <p className="w-100 ms-2">
              Please contact support team for any questions related to this
              application usage and user registration process
            </p>
          </div>

          <div className="support-business-table mb-5 ms-2">
            <h3>IT</h3>
            <p className="mb-3 ms-2">
              For any technical support, please submit the{" "}
              <a
                className="underline inf-color-blue"
                target="_blank"
                href="https://elevancehealth.service-now.com/ess?id=ant_sc_cat_item&sys_id=e91ff2b2dbca47008567fd7aae961946"
              >
                IT Services Generic Request.
              </a>{" "}
              <br />
              Select the Assignment Group : 
              <b>CoC WebPortal DevOps Support  </b>
            </p>
            <table className="w-100 ms-2">
              <thead className="">
                <tr>
                  <th></th>
                  <th></th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <tr className="even">
                  <td>
                    <b>Cloud Support Team</b>
                  </td>
                  <td></td>
                  <td>dl-CoC-WebPortal-Support@anthem.com</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="support-business-table ms-2 mb-4">
            <h3>Business</h3>
            <table className="w-100 ms-2">
              <thead className="">
                <tr>
                  <th></th>
                  <th></th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <tr className="even">
                  <td>
                    <b>Business Team</b>
                  </td>
                  <td></td>
                  <td></td>
                </tr>
                {/* <tr className="odd">
                  <td>
                    <b>Beacon</b>
                  </td>
                  <td></td>
                  <td>dl-DEVA-BEACON-Cloud-Support@anthem.com</td>
                </tr>
                <tr className="even">
                  <td>
                    <b>Caremore</b>
                  </td>
                  <td></td>
                  <td>dl-DEVA-CMOR-Cloud-Support@anthem.com</td>
                </tr>
                <tr className="odd">
                  <td>
                    <b>MyNexus</b>
                  </td>
                  <td></td>
                  <td>dl-DEVA-myNexus-Cloud-Support@anthem.com</td>
                </tr> */}
              </tbody>
            </table>
          </div>
        </div>

        <div className="d-flex justify-content-end">
          <div className="mb-4 w-75">
            <h3> References </h3>
            <p className="w-100 ms-2">
              <ul>
                <li>
                  <a href="#registrationsteps">
                    Application Registration Steps
                  </a>
                </li>
                <li>
                  <a className="" href="/Business/MyFileGateway">
                    Upload files via Enterprise File Exchange (My file gateway)
                  </a>
                </li>
                <li>
                  <a href="#dataaccesssteps">Data Access Steps</a>
                </li>
                <li>
                  <a href="#multitenantsteps">Multi Tenant Information</a>
                </li>
              </ul>
            </p>
          </div>
        </div>
      </div>

      {/* <hr />
      <div className="container home-content">
        <div id="registrationsteps" className="mb-4 pt-5">
          <h3> Application Registration Steps </h3>
          <p className="w-100 ms-2">
            Please follow the below steps for application registration
          </p>

          <div className="registrsteps mb-5 ms-2">
            <h3>1. Register</h3>
            <div className="ms-5">
              <p>
                Please submit the{" "}
                <a
                  className="underline inf-color-blue"
                  target="_blank"
                  href="/Register/RegisterUser"
                >
                  register
                </a>{" "}
                form. And enter your First Name, Last Name, Group Name and other
                required details
              </p>
              <p>
                For all business users, select role as &quot;Tenant-User&quot;
                and access type as APP_USERS.
                <br />
                <span className="font14">
                  *Tenant = Beacon, Caremore ,MyNexus etc.. <br /> Example:
                  Beacon-User
                </span>
              </p>
              <img
                src="~/Images/register.png"
                width="300"
                height="300"
                alt="register snapshot"
              />
            </div>
          </div>
          <div className="registerssubmit mb-5 ms-2">
            <h3>2. IT Service Request</h3>
            <div className="ms-5">
              Please submit{" "}
              <a
                className="underline inf-color-blue"
                target="_blank"
                href="https://anthem.service-now.com/ess?id=ant_sc_cat_item&sys_id=e91ff2b2dbca47008567fd7aae961946"
              >
                Network Active Directory Group User Access
              </a>{" "}
              form to add you to User Active Directory Group
              <br />
              Fill the form fields as below
              <br />
              <ul className="mt-3">
                <li>
                  Request Type : <b>New</b>
                </li>
                <li>
                  Domain :
                  <span>
                    <span>
                      For non-prod, select <b>DEVAD</b>.{" "}
                    </span>
                    <span>
                      For prod, select <b>US</b>
                    </span>
                  </span>
                </li>
                <li>
                  Group Name : <b>DEVA_APP_USERS </b>
                </li>
                <li>Finally click on Submit Request</li>
              </ul>
            </div>
          </div>
        </div>
        <hr />
        <div id="dataaccesssteps" className="mb-4">
          <h3> Data Access Steps </h3>
          <p className="w-100 ms-2 font10">
            Business Users can access the data from Web Portal. Backend services
            access is restricted and it is available only for IT team.
          </p>
          <div className="ms-5">
            Access Types:
            <ul>
              <li>APP_USERS : Read-Only</li>
              <li>APP_ADMIN : Application Level Admin Operations</li>
              <li>APP_DEVELOPERS : IT Only</li>
              <li>SUPER_ADMIN : Read, Write including all backend services</li>
            </ul>
          </div>
        </div>

        <hr />
        <div id="multitenantsteps" className="mb-4">
          <h3> Multi Tenant Information </h3>
          <p className="w-100 ms-2">Coming soon...</p>
        </div>
      </div> */}
    </>
  );
}
