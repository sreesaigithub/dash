import React from "react";

function Privacy() {
  return (
    <div class="home-content container my-4 mx-auto">
      <h3>Privacy Policy</h3>
      <p>
        IMPORTANT : This application is intended for internal use only. By
        logging in, you are accepting these terms and agreeing to use this
        Application in accordance with the elevance health licensing agreement
      </p>
    </div>
  );
}

export default Privacy;
