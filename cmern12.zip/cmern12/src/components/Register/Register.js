import React from "react";
import { useState, useEffect } from "react";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../Site.css";
import "./RegisterPage.css";
import ModalBox from "../Utility/ModalBox";
import { useNavigate } from "react-router-dom";
import Spinner from "../Dashboard/ExecutiveDashboard/Overview/spinner";

function RegisterPage() {
  const [Groupname, setGroupname] = useState([]);
  const [Role, setRole] = useState([]);
  const [Accesstype, setAccesstype] = useState([]);
  const [show, setShow] = useState(false);
  const [parentModalData, setParentModalData] = useState({});
  const [terms, setTerms] = useState([]);
  const [nameFocused, setNameFocused] = useState(false);
  const [checked, setChecked] = useState(false);
  const [loadingMaster, setLoadingMaster] = useState(false);
  const [registerData, setRegisterData] = useState({
    REGISTRATION_ID: 0,
    FIRST_NAME: "",
    LAST_NAME: "",
    USR_LOC_CD: "",
    PLAN_NAME: "",
    WORK_EMAIL_ID: "",
    USERID: "",
    SECRET_QUESTION: "",
    SECRET_ANSWER: "",
    ROLE: "",
    ACCESS_TYPE: "",
    BUINSESS_JUSTIFICATION: "",
    USER_IP_ADDRESS: "0.0.0.0",
    APPROVER_COMMENTS: null,
    UPDATED_BY: "ADMIN",
    CREATED_BY: "ADMIN",
    UPDATED_DATE: null,
    CREATION_DATE: null,
    IsAPPROVED: "N",
    IsPROCESSED: "N",
    IsDENIED: "",
    MBR_ROLE_ID: "",
    SECURITY_QUESTION: "",
    ANSWER: "",
    JUSTIFICATION: "",
  });

  let navigate = useNavigate();

  const baseUrl = window.__RUNTIME_CONFIG__.REACT_APP_BASE_API_URL;
  //const baseUrl = "http://localhost:8080/cocwp/api"; 

  const Insertemployee = (e) => {
    setLoadingMaster(true);
    e.preventDefault();
    axios({
      method: "post",
      url: `${baseUrl}/register/registerUser`,
      data: registerData,
    }).then((response) =>{
      setLoadingMaster(false); 
      setParentModalData(response.data);
       setShow(true)
      });
  };

  const handleInputChange = (e) => {
    setRegisterData({
      ...registerData,
      [e.target.name]: e.target.value,
    });
  };

  const handleClick = () => setChecked(!checked);
  useEffect(() => {
    axios.get(`${baseUrl}/register/Group`).then((res) => {
      setRegisterData({ ...registerData, PLAN_NAME: res.data });
      setGroupname(res.data);
    });
  }, []);
  useEffect(() => {
    axios.get(`${baseUrl}/register/GroupMember`).then((res) => {
      setRegisterData({ ...registerData, ROLE: res.data });
      setRole(res.data);
    });
  }, []);

  useEffect(() => {
    axios.get(`${baseUrl}/register/Access`).then((res) => {
      setAccesstype(res.data);
      setRegisterData({ ...registerData, ACCESS_TYPE: res.data });
    });
  }, []);

  useEffect(() => {
    axios
      .get(`${baseUrl}/register/Terms?GROUP_NAME=${registerData.PLAN_NAME}`)
      .then((res) => setTerms(res.data));
  }, [registerData.PLAN_NAME]);

  useEffect(() => {
    if (registerData.WORK_EMAIL_ID != "" && registerData.PLAN_NAME != "") {
      fetch(
        `${baseUrl}/register/EmailMatch?WORK_EMAIL_ID=${registerData.WORK_EMAIL_ID}&&GROUP_NAME=${registerData.PLAN_NAME}`
      )
        .then((res) => res.json())
        .then((output) => {
          console.log(output);
          if (output.title == "Restricted") {
            setParentModalData(output);
            setShow(true);
            setRegisterData({
              ...registerData,
              WORK_EMAIL_ID: "",
              PLAN_NAME: "",
            });
          } else {
            setShow(false);
          }
        });
    }
  }, [registerData.WORK_EMAIL_ID, registerData.PLAN_NAME]);

  const closeModal = () => {
    setShow(false);
    navigate("../../Home");
  };
  return (
    <div className="container registercontainer">
      {loadingMaster ? (
        <Spinner>
          <i className="fa fa-spinner" aria-hidden="true"></i>
        </Spinner>
      ) : (
      <form>
        <div className="eva-register-container">
          <div>
            <div>
              <h1 className="title">Enter your details to register</h1>
            </div>

            <table>
              <tr>
                <td>
                  <div>
                    <label>First Name</label>
                  </div>
                </td>
                <td>
                  <div>
                    <input
                      id="Firstname"
                      type="text"
                      name="FIRST_NAME"
                      value={registerData.FIRST_NAME}
                      className="form-control"
                      onChange={handleInputChange}
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <td>
                  <label>Last Name</label>
                </td>
                <td>
                  <input
                    id="Lastname"
                    type="text"
                    name="LAST_NAME"
                    value={registerData.LAST_NAME}
                    className="form-control"
                    onChange={handleInputChange}
                  />
                </td>
              </tr>
              <tr>
                <td>
                  <label className="required">Work Email</label>
                </td>
                <td>
                  <input
                    id="Workemail"
                    type="email"
                    name="WORK_EMAIL_ID"
                    value={registerData.WORK_EMAIL_ID}
                    className="form-control"
                    onChange={handleInputChange}
                    onBlur={(e) =>
                      setNameFocused({
                        ...registerData,
                        WORK_EMAIL_ID: e.target.value,
                      })
                    }
                    required
                  />
                </td>
              </tr>
              <tr>
                <td>
                  <label className="required">Specify US Domain ID</label>
                </td>
                <td>
                  <input
                    id="SpecifyId"
                    type="text"
                    name="USERID"
                    value={registerData.USERID}
                    className="form-control"
                    onChange={handleInputChange}
                    required
                  />
                </td>
              </tr>
              <tr>
                <td>
                  <label className="required">Group Name</label>
                </td>
                <td>
                  <select
                    id="Groupname"
                    type="text"
                    name="PLAN_NAME"
                    value={registerData.PLAN_NAME}
                    className="form-control"
                    onChange={handleInputChange}
                    required
                  >
                    {Groupname.map((group) => (
                      <option key={group} value={group}>
                        {group}
                      </option>
                    ))}
                  </select>
                </td>
              </tr>
              <tr>
                <td>
                  <label className="required">Secret Question</label>
                </td>
                <td>
                  <select
                    id="SecretQuestion"
                    type="text"
                    name="SECRET_QUESTION"
                    value={registerData.SECRET_QUESTION}
                    className="form-control"
                    onChange={handleInputChange}
                    required
                  >
                    <option selected>Select your security questions</option>
                    <option>What is your childhood favourite place?</option>
                    <option>What is your favourite place to visit?</option>
                    <option>Who is your favourite sportsperson?</option>
                  </select>
                </td>
              </tr>
              <tr>
                <td>
                  <label className="required">Secret Answer</label>
                </td>
                <td>
                  <input
                    id="SecretAnswer"
                    type="text"
                    name="SECRET_ANSWER"
                    value={registerData.SECRET_ANSWER}
                    className="form-control"
                    onChange={handleInputChange}
                    required
                  />
                </td>
              </tr>
              <tr>
                <td>
                  <label className="required">Role</label>
                </td>
                <td>
                  <select
                    id="Role"
                    name="ROLE"
                    value={registerData.ROLE}
                    className="form-control"
                    onChange={handleInputChange}
                    required
                  >
                    {Role.map((group) => (
                      <option key={group} value={group}>
                        {group}
                      </option>
                    ))}
                  </select>
                </td>
              </tr>
              <tr>
                <td>
                  <label className="required">Access Type</label>
                </td>
                <td>
                  <select
                    id="AccessType"
                    name="ACCESS_TYPE"
                    value={registerData.ACCESS_TYPE}
                    className="form-control"
                    onChange={handleInputChange}
                  >
                    {Accesstype.map((access) => (
                      <option key={access} value={access}>
                        {access}
                      </option>
                    ))}
                  </select>
                </td>
              </tr>
              <tr>
                <td>
                  <label className="required">Business Justification</label>
                </td>
                <td>
                  <textarea
                    id="Justification"
                    name="BUINSESS_JUSTIFICATION"
                    value={registerData.BUINSESS_JUSTIFICATION}
                    className="form-control"
                    onChange={handleInputChange}
                    required
                  ></textarea>
                </td>
              </tr>
              <tr>
                <td>
                  <label>Terms And Conditions</label>
                </td>
                <td>
                  <textarea
                    id="terms"
                    rows="4"
                    value={terms}
                    className="form-control"
                    readOnly
                  ></textarea>
                </td>
              </tr>
              <tr>
                <td>
                  <label className="required">I Agree</label>
                </td>
                <td>
                  <input
                    type="checkbox"
                    onClick={handleClick}
                    checked={checked}
                    id="checkbox"
                    name="Checkboxes"
                    //onChange={handleInputChange}
                  />
                </td>
              </tr>
              <tr></tr>
              <tr>
                <td></td>
                <td>
                  <div>
                    {registerData.ACCESS_TYPE !== "" &&
                    registerData.ROLE !== "" &&
                    registerData.WORK_EMAIL_ID !== "" &&
                    registerData.SECRET_ANSWER !== "" &&
                    checked === true &&
                    registerData.PLAN_NAME !== "" ? (
                      <button
                        id="btnSubmit"
                        type="submit"
                        value="Register"
                        onClick={Insertemployee}
                        className="btn btn-terracosta"
                      >
                        Register
                      </button>
                    ) : (
                      <button
                        id="btnSubmit"
                        type="button"
                        value="Register"
                        disabled
                      >
                        Register
                      </button>
                    )}
                  </div>
                </td>
                <td></td>
              </tr>
            </table>
          </div>
          <div className="col-md-5">
            <h3> Role and Access Information </h3>
            <p className="w-70 ml-4">
              <ul>
                <li>
                  For all business users, select role as "Plan Presidents" and
                  access type will be APP_USERS. *Tenant = Elevance Health
                  Example: Plan Presidents
                </li>
                <li>
                  For all devOps, select role as "DevOps" and access type will
                  be DevOps. *Tenant = Elevance Health Example: Plan Presidents
                </li>
              </ul>
            </p>
          </div>
        </div>
        
        <ModalBox
          modalShow={show}
          handleClose={closeModal}
          modalData={parentModalData}
        >
          <a
            href="#"
            className="btn btn-success"
            data-dismiss="modal"
            onClick={() => closeModal()}
          >
            OK
          </a>
        </ModalBox>
      </form>
      )}
    </div>
  );
}

export default RegisterPage;
