import React, { useState } from "react";
import { Modal } from "react-bootstrap";

export default function ModalBox({
  modalShow,
  handleClose,
  modalData,
  children,
}) {
  return (
    <>
      <Modal show={modalShow} onHide={() => handleClose()}>
        <Modal.Header closeButton>
          <h3 className="modal-title">{modalData.title}</h3>
        </Modal.Header>
        <Modal.Body>
          <div className="d-flex">
            <i
              className="fa fa-exclamation-triangle text-warning font24 mr-4"
              aria-hidden="true"
            ></i>
            <h4 dangerouslySetInnerHTML={{ __html: modalData.content }}>
              {/* {modalData.content} */}
              {/*Message: Group <span id="groupname"></span> is restricted to use DEVA. For more details, Please contact DEVA Cloud Support.*/}
            </h4>
          </div>
        </Modal.Body>
        <Modal.Footer>
          {/*<a href="#" className="btn btn-success" data-dismiss="modal" onClick={() => handleClose()} >OK</a>*/}

          {children}
        </Modal.Footer>
      </Modal>
    </>
  );
}
