import React, { Component } from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import RegisterPage from "./components/Register/Register";
//import LandingHome from "./components/Home/Home";
import Header from "./components/Shared/Header";
import Support from "./components/Shared/Support";
import { Callback } from "./components/Auth/callback";
import { Logout } from "./components/Auth/logout";
import { LogoutCallback } from "./components/Auth/logoutCallback";
import { PrivateRoute } from "./routes/privateRoute";
import { SilentRenew } from "./components/Auth/silentRenew";
import { Login } from "./components/Auth/Login";
import { Navigate } from "react-router";
import { AuthProvider } from "./providers/authProvider";
import HomePage from "./components/Dashboard/impactTracking/pages/Home";
import ViewResults from "./components/Dashboard/impactTracking/pages/ViewResults";
import Rolesandgroups from "./components/Admin/AdminOperations/Rolesandgroups";
import Users from "./components/Admin/AdminOperations/Users";
import Footer from "./components/Shared/Footer";
import ExecutiveDashboardHeader from "./components/Dashboard/ExecutiveDashboard/ExecutiveDashboardHeader";
import Privacy from "./components/Shared/Privacy";
import EditGroup from "./components/Admin/AdminOperations/EditGroup";
import EditUserInAdmin from "./components/Admin/AdminOperations/EditUserInAdmin";

// import DashboardLander from "./components/dashboard/dashboardlander";
//import ReportsDashboard from "./components/Dashboard/reportsdashboard";

import Home from "./components/Home/Home";
import PowerbiBoard from "./components/Dashboard/powerbiBoard";
import LoggedOut from "./components/Auth/LoggedOut";
import IdleTimerContainer from "./components/Shared/IdleTimerContainer";

const pathvalue = 1;
const key1 = window.__RUNTIME_CONFIG__.REACT_APP_AUTH_URL;
console.log("Key1: " + key1);
const key2 = window.METADATA_OIDC.issuer;
console.log("Key2: " + key2);
const var_NODE_ENV = process.env.NODE_ENV;
console.log("NODE_ENV : " + var_NODE_ENV);
class App extends Component {
  render() {
    return (
      <div>
        <AuthProvider>
          <Router basename="/cocwp">
            <Header />

            <Routes>
              <Route exact={true} path="/signin-oidc" element={<Callback />} />
              <Route exact={true} path="/logout" element={<Logout />} />
              <Route
                exact={true}
                path="/logout/callback"
                element={<LogoutCallback />}
              />

              <Route
                exact={true}
                path="/silentrenew"
                element={<SilentRenew />}
              />
              <Route
                path="/private"
                element={
                  <PrivateRoute>
                    <Login />
                  </PrivateRoute>
                }
              />
              <Route exact={true} path="/loggedout" element={<LoggedOut />} />
              <Route path="/api/oidc/okta-redirect" exact element={<Login />} />
              <Route
                path="/"
                element={pathvalue ? <Navigate to="/Home" /> : <Home />}
              />
              {/* <Route path="/Dashboard" element={<ExecutiveHeader />} /> */}
              <Route path="/Home" element={<Home />} />
              <Route path="/register" element={<RegisterPage />} />
              <Route path="/impacttracking" element={<HomePage />} />
              <Route
                path="/impacttracking/viewresults"
                element={<ViewResults />}
              />
              <Route path="/privacy" element={<Privacy />} />

              <Route path="/Support" element={<Support />} />
              {/* Admin */}
              <Route
                path="/devops/adminops/rolesgroups"
                element={<>{<Rolesandgroups />}</>}
              />
              <Route
                path="/devops/adminops/rolesgroups/editgroup"
                element={<>{<EditGroup />}</>}
              />
              <Route path="/devops/adminops/users" element={<Users />} />
              <Route
                path="/devops/adminops/users/EditUserInAdmin"
                element={<EditUserInAdmin />}
              />
              <Route
                path="/dashboard"
                element={
                  <PrivateRoute>
                    <Home />
                  </PrivateRoute>
                }
              />

              <Route
                path="/ExecutiveDashboard"
                element={
                  <>
                    <PrivateRoute>
                      <ExecutiveDashboardHeader />
                    </PrivateRoute>
                  </>
                }
              />

              <Route
                path="/powerbi"
                element={
                  <>
                    <PrivateRoute>
                      <PowerbiBoard />
                    </PrivateRoute>
                  </>
                }
              />
            </Routes>
            <Footer />

            <IdleTimerContainer />
          </Router>
        </AuthProvider>
      </div>
    );
  }
}

export default App;
