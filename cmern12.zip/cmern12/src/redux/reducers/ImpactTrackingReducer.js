import { RETRIEVE_HOME_JOBS_INFO, RETRIEVE_BALANCE_METRICS_INFO, RETRIEVE_SMD_SUMMARY_INFO, RETRIEVE_VALUES_FILTER_INFO, RUN_STAGE_1_JOBS_UPDATE, STAGE_1_ROW_DATA_SELECTED, TRACKING_JOBS_LOADING, TRACKING_STAGE_FILTER_RESET, TRACKING_STAGE_FILTER_UPDATE, CLEAR_STAGE_1_ROW_DATA, RETRIEVE_OUTCOMES_TABLE_INFO, IMPACT_TRACKING_ERROR, RUN_STAGE_2_JOB_UPDATE, SET_MATRIX_SUMMARY_REPORT } from './../../helper/constants';
import { RETRIEVE_METRIC_SUMMARY_INFO, RETRIEVE_COST_CURVE_INFO, RETRIEVE_PARALLEL_ADJUSTED_INFO, RETRIEVE_PARALLEL_UNADJUSTED_INFO, RETRIEVE_PARALLEL_METRIC_INFO, RETRIEVE_IMPACT_EVENTS_INFO } from './../../helper/constants';

const initialState = {
  loading: false,
  valuesFilter: {
    "filters": {
      "program_name": [],
      "lob": [],
      "sub_lob": [],
      "funding_type": [],
      "region": [],
      "cohort_period_end": 0,
      "cohort_period_start": 0
    },
    "member_vol": {}
  },
  stageFilter: {
    "program_name": "",
    "lob": "",
    "sub_lob": "",
    "region": "",
    "funding_type": "",
    "amount_type": "ALWD",
    "cohort_period_start": 0,
    "cohort_period_end": 0,
    "follow_up_period": 3
  },
  resetFilter: {
    "program_name": "",
    "lob": "",
    "sub_lob": "",
    "region": "",
    "funding_type": "",
    "amount_type": "ALWD",
    "cohort_period_start": 0,
    "cohort_period_end": 0,
    "follow_up_period": 3
  },
  jobStatusTableData: [],
  populationBalanceTableData: [],
  smdSummaryData: [],
  parallelAdjustedData:[],
  parallelUnAdjustedData: [],
  parallelMetricData: [],
  victCostCurve: [],
  matrixSummaryData: [],
  jobsStatusInfo: {},
  inProgressJobsInfo: [],
  completeJobsInfo: [],
  widgetInfoData: [],
  refreshEventsData:[],
  stage1RowDataSelected: {},
  outComesTableInfo: [],
  error: "",
};

function impactReducer(state = { ...initialState }, action) {
  const newState = { ...state };
  switch (action.type) {
    case TRACKING_JOBS_LOADING:
      return { ...state, loading: true };
    case TRACKING_STAGE_FILTER_UPDATE:
      newState.stageFilter = { ...action.payload };
      return newState;
    case TRACKING_STAGE_FILTER_RESET:
      newState.stageFilter = { ...initialState.resetFilter };
      return newState;
    case RUN_STAGE_1_JOBS_UPDATE:
      newState.jobStatusTableData = action.payload;
      return newState
    case RETRIEVE_VALUES_FILTER_INFO:
      const filterInfoData = action.payload;
      const {stageFilter} = newState;
      const { cohort_period_start, cohort_period_end } = stageFilter;
      if (cohort_period_start === 0 || cohort_period_end === 0) {
        stageFilter.cohort_period_start = cohort_period_start === 0 ? filterInfoData.filters.cohort_period_start : cohort_period_start;
        stageFilter.cohort_period_end = cohort_period_end === 0 ? filterInfoData.filters.cohort_period_end : cohort_period_end;
        stageFilter.program_name =  filterInfoData.filters.program_name[0];
        stageFilter.lob =  filterInfoData.filters.lob[0];
        stageFilter.sub_lob =  filterInfoData.filters.sub_lob[0];         
        stageFilter.region =  filterInfoData.filters.region[0];      
        stageFilter.funding_type =  filterInfoData.filters.funding_type[0];
      } else {
        const filterStart = Number(cohort_period_start);
        const filterEnd = Number(cohort_period_end);
        const kpiStart = Number(filterInfoData.filters.cohort_period_start);
        const kpiEnd = Number(filterInfoData.filters.cohort_period_end);
        
        stageFilter.cohort_period_start = filterStart > kpiStart && filterStart < kpiEnd ? filterStart : kpiStart;
        stageFilter.cohort_period_end = filterEnd > kpiStart && filterEnd < kpiEnd ? filterEnd : kpiEnd;        
      }
      newState.stageFilter = {...stageFilter};
      newState.valuesFilter = { ...filterInfoData };
      return newState;
    case RETRIEVE_HOME_JOBS_INFO:
      const jobsInfoData = action.payload;
      newState.inProgressJobsInfo = jobsInfoData[0];
      newState.completeJobsInfo = jobsInfoData[1];
      return newState;
    case RETRIEVE_IMPACT_EVENTS_INFO:
      const eventsInfoData = action.payload;
      newState.refreshEventsData = eventsInfoData;
      return newState;      
    case RETRIEVE_BALANCE_METRICS_INFO:
      const metricsInfoData = action.payload;
      newState.populationBalanceTableData = metricsInfoData;
      return newState;
    case RETRIEVE_PARALLEL_ADJUSTED_INFO:
      const parallelAdjustedInfo = action.payload;
      newState.parallelAdjustedData = parallelAdjustedInfo;
      return newState;
    case RETRIEVE_PARALLEL_UNADJUSTED_INFO:
      const parallelUnAdjustedInfo = action.payload;
      newState.parallelUnAdjustedData = parallelUnAdjustedInfo;
      return newState;      
    case RETRIEVE_PARALLEL_METRIC_INFO:
      const parallelMetricInfo = action.payload;
      newState.parallelMetricData = parallelMetricInfo;
      return newState;      
    case RETRIEVE_SMD_SUMMARY_INFO:
      const smdSummaryInfo = action.payload;
      newState.smdSummaryData = smdSummaryInfo;
      return newState;      
    case STAGE_1_ROW_DATA_SELECTED:
      const rowSelected = action.payload;
      newState.stage1RowDataSelected = rowSelected;
      return newState;
    case CLEAR_STAGE_1_ROW_DATA:
      newState.stage1RowDataSelected = {};
      return newState;
    case RETRIEVE_OUTCOMES_TABLE_INFO:
      newState.outComesTableInfo = action.payload;
      return newState;
    case RETRIEVE_METRIC_SUMMARY_INFO:
      newState.matrixSummaryData = action.payload;
      return newState;
    case RETRIEVE_COST_CURVE_INFO:
      newState.victCostCurve = action.payload;
      return newState;
    case IMPACT_TRACKING_ERROR:
      newState.error = action.payload;
      return newState;
    case RUN_STAGE_2_JOB_UPDATE:
      newState.jobStatusTableData = action.payload;
      return newState
    case SET_MATRIX_SUMMARY_REPORT:
      newState.matrixSummaryData = action.payload;
      return newState
    default:
      return state;
  }
};

export default impactReducer;
