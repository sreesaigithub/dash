import axios from "axios";

import {
  SHOW_LOADING_ACTION,
  USER_AUTHENTICATE_REQUEST,
  USER_AUTHENTICATE_SUCCESS,
  USER_AUTHENTICATE_FAILURE,
  UPDATE_HEADER_TEXT,
  UPDATE_TIER_INFO,
} from "../../helper/constants";

const baseUri = window.__RUNTIME_CONFIG__.REACT_APP_BASE_API_USER_MGNT_URL;

export const authenticateuser = (userId, groupNames, firstname, lastname) => {
  return (dispatch) => {
    dispatch(userauthenticaterequest());
    axios
      .post(`${baseUri}/account/validate`, {
        userId: userId,
        groupNames: groupNames,
        firstName: firstname,
        lastName: lastname,
      })
      .then((response) => {
        const user = response.data;
        dispatch(userauthenticatesuccess(user));
      })
      .catch((error) => {
        dispatch(userauthenticatefailure(error.message));
      });
  };
};

export const userauthenticaterequest = () => {
  return {
    type: USER_AUTHENTICATE_REQUEST,
  };
};

export const userauthenticatesuccess = (user) => {
  return {
    type: USER_AUTHENTICATE_SUCCESS,
    payload: user,
  };
};

export const userauthenticatefailure = (error) => {
  return {
    type: USER_AUTHENTICATE_FAILURE,
    payload: error,
  };
};

export const updateheadertext = (data) => {
  return {
    type: UPDATE_HEADER_TEXT,
    payload: data,
  };
};

export const showLoading = (showFlag) => {
  return {
    type: SHOW_LOADING_ACTION,
    payload: showFlag,
  };
};
export const updatetierInfo = (tierInfo) => {
  return {
    type: UPDATE_TIER_INFO,
    payload: tierInfo,
  };
};
